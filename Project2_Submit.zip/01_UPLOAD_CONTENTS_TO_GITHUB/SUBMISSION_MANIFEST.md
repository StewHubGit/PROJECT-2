# Project 2 submission manifest

**DRAFT — not submission-ready.** Missing locations/evidence remain explicitly UNRESOLVED. A configured URL is not certified until it has been checked. No local path is presented as a submission location.

| Part | Submission location | Status |
| --- | --- | --- |
| GitHub repository | **UNRESOLVED** | Prepared; publication not verified |
| README and start instructions | **UNRESOLVED** | Prepared; publication not verified |
| Decision memo — also attach to Brightspace | **UNRESOLVED** | Prepared; publication not verified |
| Validation/AI use and Locked Changed-Input Record — also attach | **UNRESOLVED** | Prepared; publication not verified |
| Python web app | **UNRESOLVED** | Prepared; publication not verified |
| Point-in-time data card | **UNRESOLVED** | Prepared; publication not verified |
| Visible frozen results | **UNRESOLVED** | Prepared; publication not verified |
| Personal robo-advisor and selected Rule B | **UNRESOLVED** | Prepared; publication not verified |
| Final package verification | **UNRESOLVED** | Prepared; publication not verified |
| Locked Changed-Input Record evidence | **UNRESOLVED** | Prepared; publication not verified |
| Prediction commit — before run | **UNRESOLVED** | Human AI-off exercise/chronology requires evidence |
| Result commit — after first run | **UNRESOLVED** | Human AI-off exercise/chronology requires evidence |
| Video 1 — YouTube | **UNRESOLVED** | Recording / enabled transcript PENDING |
| Video 1 matched transcript | **UNRESOLVED** | Must match actual recording; scripts are not transcripts |
| Video 2 — YouTube | **UNRESOLVED** | Recording / enabled transcript PENDING |
| Video 2 matched transcript | **UNRESOLVED** | Must match actual recording; scripts are not transcripts |
| Video 3 — YouTube | **UNRESOLVED** | Recording / enabled transcript PENDING |
| Video 3 matched transcript | **UNRESOLVED** | Must match actual recording; scripts are not transcripts |
| Submission manifest | **UNRESOLVED** | Prepared; publication not verified |

All populated locations above are GitHub links, except the three YouTube video links. Keep transcripts on GitHub or link them from the repository. Scripts do not satisfy recording/transcript delivery.

Brightspace: submit the repository URL and manifest; attach the exact same `docs/decision-memo.md` and `docs/validation-and-ai-use.md` files. Do not attach video files. This script prepares files; it does not submit them.

Ownership confirmation: PENDING. The genuine AI-off prediction/result chronology and actual recordings must be verified separately.
