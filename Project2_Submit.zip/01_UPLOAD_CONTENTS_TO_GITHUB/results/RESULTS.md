AI announcement: Prepared with OpenAI Codex assistance; education, not investment advice.

# Frozen Project 2 result

Freeze: 2026-11-10. Prices 2021-09-30 through 2026-09-30; 60 monthly returns.

**Decision: REDESIGN. Live capital: $0.** The frozen candidate fails the net hurdle under the assumed cost test. No allocation was retuned.

| Run | SGOV | IEF | BND | VT | Gross arithmetic estimate | Sample volatility |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| All months | 65.00% | 0.00% | 0.00% | 35.00% | 6.58% | 5.29% |
| Last 36 months | 85.00% | 0.00% | 0.00% | 15.00% | 6.81% | 1.79% |

Existing window stress: largest allocation change **20.00 percentage points**.

## COST-01 single claim test

Assume a common **25 bp/year** additional drag; keep prices, estimates, weights, target and window fixed. Taxes are not modeled. The cost is an assumption, not a measured bill.

| Measure | Frozen result |
| --- | ---: |
| Candidate after assumed cost | 6.33% |
| Net planning hurdle | 6.50% |
| 60/40 reference after same assumed cost | 6.72% |
| Candidate minus reference | -38.99 bp |
| Maximum additional drag before candidate misses hurdle | 7.81 bp |

**Claim outcome: FAIL.** These are in-sample annualized arithmetic estimates, not realized after-cost returns or a rolling five-year CPI outcome. The 60/40 reference has 0% SGOV and fails the selected 3% reserve screen; it is an evaluation reference, not an approved substitute.

## Baselines and mandate checks

| Baseline | Gross arithmetic | After assumed cost | Volatility | SGOV reserve | Reserve check |
| --- | ---: | ---: | ---: | ---: | --- |
| 60/40 reference | 6.97% | 6.72% | 10.96% | 0.00% | FAIL |
| Equal weight | 3.35% | 3.10% | 6.65% | 25.00% | PASS |
| Inverse volatility | 3.37% | 3.12% | 1.34% | 85.04% | PASS |

- **long only full investment:** PASS on the grid.
- **reserve:** PASS: SGOV 65% versus selected minimum 3%.
- **net return hurdle:** FAIL under COST-01 assumption; rolling five-year CPI+4 objective not established.
- **liquidity and issuer:** Conditional on ETF eligibility assumptions; no live dealing or look-through audit.
- **turnover:** NOT ESTABLISHED: starting holdings and trading path absent.
- **calendar year loss S9:** UNRESOLVED: CIO definition and breach response absent.

### Same-rule portfolio comparison

| Portfolio | Net estimate | Volatility | Reserve | Modeled verdict |
| --- | ---: | ---: | ---: | --- |
| Constrained portfolio | 6.33% | 5.29% | 65.00% | FAIL: S2 net planning hurdle |
| Equal weight | 3.10% | 6.65% | 25.00% | FAIL: S2 net planning hurdle |
| 60/40 reference | 6.72% | 10.96% | 0.00% | FAIL: S3 reserve |
| Inverse volatility | 3.12% | 1.34% | 85.04% | FAIL: S2 net planning hurdle |

Full mandate use is NOT CLEARED for every mix: realized rolling CPI, annual rebalancing/turnover, live eligibility and S9 loss governance are unresolved.

## Isolated stress runs

| Scenario | Diagnostic weights | Net estimate | Verdict |
| --- | --- | ---: | --- |
| Baseline current estimates | SGOV 65% / IEF 0% / BND 0% / VT 35% | 6.33% | STOP: net planning hurdle fails |
| Estimates: VT mean -1 percentage point | SGOV 60% / IEF 0% / BND 0% / VT 40% | 6.34% | STOP: net planning hurdle fails |
| Costs: additional drag 0 bp | SGOV 65% / IEF 0% / BND 0% / VT 35% | 6.58% | PASS modeled screen |
| Constraints: reserve minimum 70% (severe diagnostic) | INFEASIBLE | N/A | STOP: gross target/reserve infeasible |

The separate 60-to-36-month window stress above completes the four stress dimensions. The severe 70% reserve scenario is a diagnostic, not a proposed policy. The committee candidate remains frozen.

## Point-in-time signal

DGS10 RISING: 51.00 bp over 20 known observations, 2026-08-31 to 2026-09-29. Last yield 5.26%; eligible vintage 2026-09-30; proposed review 2026-10-01. Status: ADMIT saved-vintage research context.

The signal supplies research context and a data-admission gate; it does not set ETF weights. Missing required vintage means QUARANTINE / STOP, with no current-history fallback. This is a saved historical demonstration, not a live signal. See [data card](../docs/DATA_CARD.md).

## Committee controls

- **action:** REDESIGN
- **live capital usd:** 0
- **live allocation range percent:** [0, 0]
- **conditional shadow notional range usd:** [0, 1000000]
- **proposed shadow notional usd:** 1000000
- **proposed duration months:** 12
- **monitoring owner:** Sam Stewart (proposed; committee acceptance pending)
- **condition:** Written CIO objective and S9 loss definition, documented implementation costs, and a preregistered point-in-time protocol before any prospective shadow trial.
- **monitor:** Monthly audit of source/vintage receipts, reserve coverage, modeled and observed costs, overrides and allocation changes; daily reserve check in any future implementation.
- **kill rule:** Stop the shadow trial at the first unavailable required vintage, unexplained source mismatch, reserve below 3%, unapproved turnover above 25%, or breach of the CIO-approved loss rule.
- **reversal trigger:** Committee may approve a new zero-live-capital shadow protocol only after the written conditions are met. Live adoption requires a separate decision and evidence; twelve months cannot validate a rolling five-year return objective.

## Scope and trace

Adjusted history was retrieved on 2026-10-22. It supports reproduction at that research date; it is not proof of what investors knew on every historical trade date. No dynamic strategy backtest or DGS10-driven allocation exists here. Lab 18/19 stock screens are supporting research controls and do not feed ETF weights.

Trace: [raw receipts](../evidence/fund_prices_sources/sources.json) -> [prices](../data/prices.csv) -> [engine](../portfolio.py) -> [COST-01](../validation/RISKIEST_CLAIM.md) -> [memo](../docs/decision-memo.md).

[Machine-readable result](result.json) | [Reproduction checks](../validation/checks.json)
