# Three YouTube videos and transcripts

[Full exercise and recording directions](../FINISH_AND_RECORD.md). Finish the
AI-off prediction and first run before recording; review ownership before
speaking the final first-person statement. Each linked script includes screen
directions. Video 1 has complete draft narration for the current pending
exercise status; update it with the actual result and your reviewed reflection.

Scripts are drafts; no recordings or matched transcripts exist in this package.
Review first-person claims and confirm the ownership statement before recording.
Each recording must open with the AI-use and ownership statements in its script.

| Video | Record | Deliver |
| --- | --- | --- |
| [1 — How it changed](VIDEO_1_HOW_IT_CHANGED.md) | Explain the evolution of the system/thinking and one specific AI output you checked. Describe only your actual views. | YouTube link with transcripts enabled, plus a matched transcript attached or linked in the repo. |
| [2 — Code walkthrough](VIDEO_2_TECHNICAL.md) | Start from README, operate the app, trace data → code → verdict, show a test and its limits. | Same. |
| [3 — Committee presentation](VIDEO_3_COMMITTEE.md) | **First frame: app running live in Meridian mode.** Read both statements while the app is visible, then show the decision, baselines, range, conditions and monitor/stop triggers. | Same. |

Upload recordings to YouTube, not as video files in GitHub or Brightspace.
Publish/enable the transcript and verify it against the recording, especially
financial numbers and opening disclosures. Put actual transcript text in
`videos/transcripts/video-1.md` (and similarly 2/3), or provide a real accessible
transcript link. Do not rename a script “transcript” unless it matches the audio.
Set the YouTube/transcript locations in `delivery.json`, then regenerate the
manifest with `python tools/prepare_delivery.py`.
