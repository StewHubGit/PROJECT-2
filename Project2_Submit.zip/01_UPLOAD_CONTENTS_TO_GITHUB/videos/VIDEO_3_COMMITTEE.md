**AI use:** I used OpenAI Codex to help implement the apps, check calculations, assemble evidence, and draft the memo and video scripts.

**Ownership statement — pending Sam's review and confirmation:** “The analysis and the decision are mine; education, not investment advice.”

# Video 3 — Committee presentation

**Complete recording script, not a verified transcript.** Read the two opening statements without their editing labels. Bracketed screen directions are not spoken. The recording folder also has SPEAKER_SCRIPT.html with the narration and blue switch-to cues. Read the normal paragraphs aloud; use the blue boxes as silent directions.

**FIRST FRAME: the app running live** in Meridian mandate mode, with the browser/local URL and calculated results visible. Keep the app on screen while saying both opening statements. The video must not begin with a title slide, terminal, static screenshot or memo.

## Before recording

Start app.py, choose Meridian mode, restore default controls, and arrange the window so the candidate and comparison table can be read. Open docs/decision-memo.md and the validation report and AI-assisted changed-input record in adjacent tabs. The personal mode is supporting work; this is the Meridian committee decision.

## Read-aloud script

[SCREEN: BEFORE PRESSING RECORD, OPEN the LIVE APP at http://127.0.0.1:8512. Select Meridian mandate — Project 2 with default controls. The first recorded frame must show the actual app, not this script or a menu. Say both opening statements with the app visible. Keep it on screen for the recommendation and mandate paragraphs.]

My recommendation is redesign, with zero live capital allocated to this process. I do not recommend adopting the candidate or replacing it with the reference solely because its estimated return is higher.

Meridian's objective is CPI plus four percent net over rolling five-year periods, while funding quarterly distributions and preserving a twelve-month payout reserve. The working nominal return hurdle is six point five zero percent using a two point five percent CPI planning assumption.

[SCREEN: STAY IN the LIVE APP. Show Current controls with 65% SGOV / 35% VT and the 6.58% gross / 6.33% after-cost figures. Scroll to Current-control mandate verdicts so the baseline failures are readable. Keep these results visible for the next three paragraphs.]

The saved candidate is sixty-five percent SGOV and thirty-five percent VT. Its historical annualized arithmetic estimate is six point five eight percent, and sample volatility is five point two nine percent.

After an assumed twenty-five-basis-point annual additional cost, the estimate falls to six point three three percent, below the planning hurdle. The sixty-forty reference is six point seven two percent under the same cost assumption, but it has no SGOV reserve and fails that screen. Equal weight also receives its own rule-specific verdict in the app.

These are historical modeled estimates, not realized net performance. Costs are assumed and taxes are not modeled. A passing software reproduction does not change the failed return claim.

[SCREEN: In the LIVE APP turn Last 36 months only ON to show 85% SGOV / 15% VT and the 20.00-point change while reading the next paragraph. Restore the toggle OFF afterward. Then OPEN 03_DECISION_MEMO.html — Decision memo, for the paragraph beginning We cannot claim.]

The strongest operational finding is sensitivity: reducing the estimation window from sixty to thirty-six months changes the selected allocation by twenty percentage points. Before using this process, window choice and input overrides need explicit governance.

We cannot claim that the model meets the actual five-year return objective, guarantees a ten-percent loss ceiling, or establishes stable out-of-sample performance. The loss definition and breach response still require CIO approval.

[SCREEN: OPEN 04_ALLOCATION_RANGE_AND_TRIGGERS.html — Allocation range, conditions and triggers. Show the range table while reading the first paragraph, then scroll through Start conditions, Monitor and Stop as you reach those paragraphs.]

My recommended live allocation range is zero to zero percent of the hundred-million-dollar mandate: zero dollars. A separately approved shadow protocol could use zero to one million dollars of notional capital for twelve months, with no actual funding.

Before that protocol starts, require a written objective and loss rule, documented costs, starting holdings and a preregistered point-in-time process. Twelve months would test operational reliability; it cannot validate a five-year return objective.

The proposed monitoring owner is Sam Stewart, subject to accepting the role. Review sources, vintages, costs, allocation changes and exceptions monthly, and check reserves daily in any future implementation.

Stop at a missing required vintage, an unexplained source mismatch, reserves below three percent, annual turnover above twenty-five percent without approval, or a breach of the approved loss rule. The app demonstrates the missing-vintage stop directly.

[SCREEN: OPEN 05_LOCKED_RECORD.html — Completed AI-assisted changed-input test. Keep the FAIL verdict and REDESIGN decision consequence visible while reading the final paragraph.]

Reconsidering a shadow protocol requires completion of those written conditions and a separate committee decision. Any live adoption requires another decision and additional evidence. The current recommendation remains redesign, zero live capital, with failures and limitations retained.

## After recording

Verify that the first frame actually shows the running app and both statements are audible. Check the transcript's numbers against the recording. Upload to YouTube with captions/transcript available; add the real links to the manifest.

