**AI use:** I used OpenAI Codex to help implement the apps, check calculations, assemble evidence, and draft the memo and video scripts.

**Ownership statement — pending Sam's review and confirmation:** “The analysis and the decision are mine; education, not investment advice.”

# Video 2 — Code walkthrough

**Complete recording script, not a verified transcript.** Read the two opening statements without their editing labels. Bracketed screen directions are not spoken. The recording folder also has SPEAKER_SCRIPT.html with the narration and blue switch-to cues. Read the normal paragraphs aloud; use the blue boxes as silent directions.

## Before recording

Open README.md, the live combined app, portfolio.py, review.py, robo_app.py and the saved validation reports in tabs. Have the terminal visible briefly for the startup command. Install dependencies beforehand; do not spend the video waiting for pip or the full test suite.

## Read-aloud script

[SCREEN: OPEN 01_README_AND_STARTUP.html — README and start instructions. Scroll to Start and operate the web app so python -m streamlit run app.py is visible. Say both opening statements, then the next paragraph.]

This repository contains an operable Streamlit web app. From a Python three point twelve or newer environment, the README explains installation with the requirements file and startup using python dash m streamlit run app dot py. A stranger opens the printed local URL and uses the controls without needing my course folders or API keys.

[SCREEN: SWITCH TO the LIVE APP at http://127.0.0.1:8512. Select Meridian mandate — Project 2. Briefly show Mandate and point-in-time signal, then scroll to Current-control mandate verdicts to show the portfolio and baselines while reading the next paragraph.]

Meridian mode opens with the Lab 13 objective, universe, benchmark, risk measure and limits. The constrained candidate appears beside equal weight, sixty-forty and inverse volatility. All rows use the same current estimates, costs and rules, and identify a modeled pass or the failing rule. Full mandate clearance remains blocked by the missing realized path and unresolved loss governance.

[SCREEN: OPEN 03_ALLOCATION_CODE.html#estimate_from_csv — Allocation and estimation code. Show estimate_from_csv while reading the data and return-calculation paragraph.]

The saved data contain sixty-one month-end adjusted prices for SGOV, IEF, BND and VT, supplying sixty monthly returns. Each return is current price divided by previous price minus one. The estimator annualizes the arithmetic monthly mean and sample covariance.

[SCREEN: STAY ON 03_ALLOCATION_CODE.html#search_lowest_risk. Show search_lowest_risk while reading the next paragraph.]

The search enumerates long-only, fully invested mixes in five-percentage-point steps. It finds the lowest modeled volatility among mixes meeting the gross return and reserve screens. Net cost is checked afterward; the code does not silently retune a failed result.

[SCREEN: OPEN 04_CHECKS_AND_SIGNAL_CODE.html#point_in_time_signal — Mandate checks and point-in-time code. Briefly show point_in_time_signal. Then OPEN 05_DATA_CARD.html — Point-in-time data card, and scroll to App signal while reading the next paragraph.]

The saved September thirtieth DGS10 vintage contains measurements through September twenty-ninth. Its twenty-observation change is a fifty-one-basis-point rise for a proposed October first review. This is historical context and a data-admission gate, not a weight-setting forecast. The data card records measurement, vintage, acquisition and review dates.

[SCREEN: SWITCH TO the LIVE APP at http://127.0.0.1:8512, still in Meridian mode. Keep the cost control and mandate comparison visible. Change Assumed annual additional cost from 25 to 0 bp as you read the first two sentences, then restore 25 bp.]

Changing additional cost from twenty-five to zero basis points changes the modeled net-hurdle verdict. It does not clear the full mandate. 

[SCREEN: In the LIVE APP turn Last 36 months only ON. Point to 85% SGOV / 15% VT and the 20-point change, then turn it OFF. Scroll to Preserved window stress and decision controls so the estimate and constraint stress rows are visible.]

The thirty-six-month toggle shows the published twenty-percentage-point allocation shift. The stress table also shows a one-point VT mean reduction and the severe seventy-percent reserve constraint. These cover estimates, window, costs and constraints.

[SCREEN: In the LIVE APP uncheck Required saved vintage available. Show PROCESS STOP and the absence of allocation tables. After the next paragraph, recheck the box to restore calculations.]

Unchecking required vintage availability produces PROCESS STOP and halts allocation output. Restoring the required vintage restores calculation; there is no fallback to today's history.

[SCREEN: In the LIVE APP select Personal robo-advisor — Rule B. Show its questionnaire and allocation. Then OPEN 07_PERSONAL_ROBO_CODE.html#questionnaire_allocation — Personal Rule B, loss and grid code, while reading the next paragraph.]

The separate personal mode uses Sam-selected Rule B. The questionnaire allocation function implements age bounds, cash rules, reaction caps and the one-year cash override. A manual override permits direct tests.

[SCREEN: STAY ON 07_PERSONAL_ROBO_CODE.html#parse_french for the French parsing, then scroll to bond_returns for the yield approximation. Read the next paragraph.]

Monthly French Mkt-RF plus RF gives stock returns; RF gives cash returns. Only six-digit monthly rows are admitted. GS10 provides observed nominal yields for the supplied bond approximation, not a published bond index. Both sources download on every rerun.

[SCREEN: STAY ON 07_PERSONAL_ROBO_CODE.html#performance, then scroll to stock_grid while describing the loss check.]

The performance function includes initial wealth in drawdown and compounds rolling twelve-month returns. The stock grid checks every feasible ten-percent stock step while holding cash fixed, rather than assuming bonds always solve the loss constraint.

[SCREEN: SWITCH TO the LIVE APP in Personal mode. Check Override allocation by hand and use Stocks 60%, Bonds 40%, Cash 0%, with $100,000 initial investment. Show 432 months and the worst-12-month result. Then OPEN 08_TEST_RESULTS.html — Saved verification results, for the final two sentences.]

The verified sixty-forty-zero case has four hundred thirty-two months and a worst twelve-month return of minus twenty-four point four one percent ending February two thousand nine. The saved checks distinguish software success from investment suitability. The disclosed benchmarks are separate from my required AI-off exercise.

## What to show, not read

- Start command: python -m streamlit run app.py.
- Default mode: Meridian mandate — Project 2.
- Show source receipts/cards without scrolling through large raw JSON files.
- Cost: 25 → 0 → 25 bp.
- Window: 36-month toggle on, then off.
- Show the existing estimate and severe reserve rows in the stress table.
- Required vintage: uncheck to show the actual halt, then restore.
- Personal mode: enable manual override for 60/40/0; default investment is $100,000.
- These are already disclosed demonstrations, not inputs for the AI-off prediction.

## After recording

Create the matched transcript from the audio, publish/review YouTube captions, and add the real video and transcript links to the manifest.

