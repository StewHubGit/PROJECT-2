# Video 3 — actual transcript

**PENDING — replace this worksheet with the words actually spoken in the recording.**

YouTube video URL: PENDING

Transcript status: not yet supplied or verified.

Paste the actual transcript below. Correct captions against the audio, especially numbers and fund tickers. The video script is preparation and must not be presented as a matched transcript without checking the audio.
