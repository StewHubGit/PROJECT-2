**AI use:** I used OpenAI Codex to help implement the apps, check calculations, assemble evidence, and draft the memo and video scripts.

**Ownership statement — pending Sam's review and confirmation:** “The analysis and the decision are mine; education, not investment advice.”

# Video 1 — How the system and my thinking changed

**Complete recording script, not a verified transcript.** Read the two opening statements without their editing labels. Bracketed screen directions are not spoken. The recording folder also has SPEAKER_SCRIPT.html with the narration and blue switch-to cues. Read the normal paragraphs aloud; use the blue boxes as silent directions.

## Before recording

Open the original Lab 13 mandate, the running app, validation/RISKIEST_CLAIM.md, docs/validation-and-ai-use.md, and the Rule B function. Keep the screen readable. This video explains change; save the detailed code tour for Video 2.

## Read-aloud script

[SCREEN: OPEN 01_LAB13_MANDATE.html — Original Lab 13 mandate. Keep this page visible while saying both opening statements and the next two paragraphs. Do not read the blue directions aloud.]

My Project 2 starts with Meridian Foundation's hundred-million-dollar mandate: a seven-year horizon, quarterly payouts of seven hundred fifty thousand dollars, and a twelve-month payout reserve. The reserve requirement is three percent. The objective is CPI plus four percent, net of costs, over rolling five-year periods.

The first holdings checker taught an important distinction. A portfolio entirely in a ten-year Treasury could pass the supplied liquidity and issuer screens while leaving its losses and return adequacy unresolved. Passing the checks we can compute is only part of the investment decision.

[SCREEN: SWITCH TO the LIVE APP at http://127.0.0.1:8512. In App mode select Meridian mandate — Project 2. Scroll to Current-control mandate verdicts so the Constrained portfolio, Equal weight and 60/40 reference rows are visible. Keep the app visible for the next two paragraphs.]

The later system adds saved source data, a constrained allocation search, transparent baselines, stress tests and a point-in-time data-admission rule. Equal weight and sixty-forty receive the same modeled rules as the constrained candidate. Each row identifies the rule behind its verdict.

The saved candidate is sixty-five percent SGOV and thirty-five percent VT. Switching from sixty to thirty-six estimation months moves twenty percentage points from VT into SGOV. That demonstrates sensitivity to the window; it does not establish that the shorter window predicts better.

[SCREEN: OPEN 03_COST01_AI_OUTPUT_CHECK.html — AI output check: COST-01. Scroll to the evidence table showing 6.58% gross, 6.33% after cost and the failed claim. Keep it visible for the next two paragraphs.]

One AI-assisted output I checked was the interpretation of the candidate's six point five eight percent gross estimate against a six point five zero percent planning hurdle. Codex applied an assumed twenty-five-basis-point annual cost without changing the data or weights. The estimate becomes six point three three percent. Independent Decimal arithmetic reproduces the calculation.

The software check succeeds because it reproduces the financial claim's failure. The cost is an assumption, not an observed fee bill, and these are historical arithmetic estimates rather than realized performance. The sixty-forty reference has a higher estimate but fails our selected reserve rule, so it is not an automatic replacement.

[SCREEN: SWITCH TO the LIVE APP at http://127.0.0.1:8512. Select Personal robo-advisor — Rule B in App mode. Show the questionnaire and the default 65% stocks / 25% bonds / 10% cash allocation while reading the next two sentences.]

I also selected option B, the age-based rule, from options proposed by Codex. It starts stocks at one hundred minus age, bounded between zero and eighty percent, then applies explicit cash, reaction and near-term-need rules. 

[SCREEN: OPEN 06_SELECTED_RULE_B.html — Selected Rule B. Keep the rule summary visible for the rest of this paragraph. The optional 07_RULE_B_CODE.html#questionnaire_allocation page shows the exact implementation.]

Allocation and historical loss checks are code. AI assisted with implementation and explanation rather than selecting weights at runtime. This personal US-market extension is separate from Meridian's mandate.

[SCREEN: OPEN 04_LOCKED_RECORD.html — Completed AI-assisted changed-input test. Show the table with the 0 → 25 bp input change, fixed weights, 6.33% result and REDESIGN consequence. Read the next paragraph with that table visible.]

The changed-input example shown here is an AI-assisted retrospective test. It documents the input change, fixed assumptions, result and decision consequence. It was not an independent prediction committed before the run; that separate assignment requirement remains incomplete.

[SCREEN: OPEN 05_VALIDATION_AND_AI_USE.html — Validation report and locked record. Show AI contribution, human choices and one checked output while reading the takeaway and final recommendation.]

AI also helped me articulate my takeaway: an allocation needs more than a plausible explanation. I need to ask which mandate rules it meets, how assumptions change it, and what evidence would justify using it. A passing software test can preserve an adverse investment finding.

My current recommendation is redesign, with zero live capital and a conditional shadow protocol only after the stated approvals and evidence requirements are met. The evidence and limitations, including any adverse result, remain visible.

## After recording

Review the audio and create the actual transcript. Upload the video to YouTube with captions/transcript available. A script is not a transcript. Link the video and matched transcript in the manifest.

