# Project 2 videos and transcripts

Replace PENDING with the actual YouTube URL for each recording. Publish/review the caption track on YouTube. Paste the words actually spoken into the linked transcript files; they are currently unfilled worksheets.

| Video | Topic | YouTube URL | Actual transcript |
| --- | --- | --- | --- |
| 1 | System/thinking changes and one AI output checked | PENDING | [Video 1 transcript](transcripts/video-1.md) |
| 2 | Code walkthrough and operating app | PENDING | [Video 2 transcript](transcripts/video-2.md) |
| 3 | Committee presentation, opening on the running app | PENDING | [Video 3 transcript](transcripts/video-3.md) |

Recordings 1 and 2 were reported completed by Sam; links and matched transcripts were not yet supplied. Video 3 was being prepared when this file was assembled.

After adding the links/transcripts, fill delivery.json and regenerate SUBMISSION_MANIFEST.md, or replace the manifest locations manually with your real GitHub/YouTube links. All manifest locations must be GitHub links except the three YouTube links.
