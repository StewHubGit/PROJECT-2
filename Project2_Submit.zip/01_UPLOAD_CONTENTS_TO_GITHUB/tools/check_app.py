"""Optional AppTest check; requires requirements-app.txt. No browser/network required."""
from pathlib import Path
import hashlib
import json
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from streamlit.testing.v1 import AppTest


def main():
    checks = []

    def check(name, passed):
        checks.append({'name': name, 'pass': bool(passed)})
        if not passed:
            raise AssertionError(name)

    app = AppTest.from_file(str(ROOT / 'app.py'), default_timeout=30).run()
    check('Default saved-price app executes without exceptions', not app.exception)
    check('Disclosure is visible', any('education, not investment advice' in x.value for x in app.caption))
    check('Frozen REDESIGN and zero live capital visible', any('REDESIGN' in x.value and '$0' in x.value for x in app.error))
    check('Gross and assumed-net return displayed', {'6.58%', '6.33%'}.issubset({x.value for x in app.metric}))
    check('Net failure and unresolved mandate rules visible',
          any('FAIL under assumption' in str(t.value) and 'UNRESOLVED' in str(t.value) for t in app.table))
    check('Equal-weight and transparent reference verdicts visible beside portfolio',
          any(all(word in t.value.to_string() for word in ['Constrained portfolio', 'Equal weight', '60/40 reference', 'S2', 'S3']) for t in app.table))
    cost_control = next(x for x in app.number_input if x.label == 'Assumed annual additional cost (bp)')
    cost_control.set_value(0).run()
    check('One cost control flips constrained modeled verdict to PASS', not app.exception and
          any('PASS: S3, S5 and net planning screen' in t.value.to_string() for t in app.table))
    next(x for x in app.number_input if x.label == 'Assumed annual additional cost (bp)').set_value(25).run()
    next(x for x in app.checkbox if x.label == 'Required saved vintage available').set_value(False).run()
    check('Unavailable vintage visibly stops process', not app.exception and
          any('PROCESS STOP' in x.value for x in app.error))
    check('Vintage stop halts allocation and verdict calculations', not app.table and not app.metric)
    next(x for x in app.checkbox if x.label == 'Required saved vintage available').set_value(True).run()
    check('Saved-vintage signal shows known direction and change',
          any('RISING' in x.value and '51.00 bp' in x.value for x in app.info))
    next(x for x in app.number_input if x.label == 'Reserve minimum (%)').set_value(70).run()
    check('Infeasible reserve control produces visible fail instead of exception', not app.exception and
          any('No feasible grid mix' in t.value.to_string() for t in app.table))
    next(x for x in app.number_input if x.label == 'Reserve minimum (%)').set_value(3).run()
    app.toggle[0].set_value(True).run()
    check('Existing 36-month window stress executes', not app.exception and
          any(x.value == '20.00 percentage points' for x in app.metric) and
          any('85.00%' in str(x.value) and '15.00%' in str(x.value) for x in app.table))
    app.selectbox[0].select('Meridian training case').run()
    check('Training case remains available', not app.exception and any(x.value == '6.51%' for x in app.metric))
    probe = next(x for x in app.checkbox if x.label.startswith('Training stress'))
    probe.set_value(True).run()
    check('Existing training stress changes weights by 25 points', not app.exception and
          any(x.value == '25.00 percentage points' for x in app.metric))
    record = {'all_pass': True, 'checks_passed': len(checks), 'checks': checks,
        'method': 'Streamlit AppTest; no manual visual browser inspection claimed',
        'app_sha256': hashlib.sha256((ROOT / 'app.py').read_bytes()).hexdigest()}
    (ROOT / 'validation/app_checks.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
    print(f"App checks: {len(checks)}/{len(checks)} PASS")


if __name__ == '__main__':
    main()
