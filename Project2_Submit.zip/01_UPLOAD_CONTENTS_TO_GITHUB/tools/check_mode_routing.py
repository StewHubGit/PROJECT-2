"""Exercise the real app entry point switching between both modes."""
from pathlib import Path
import sys
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from streamlit.testing.v1 import AppTest
import robo_app

payloads = {'french': (ROOT / 'validation/robo/french.zip').read_bytes(),
            'gs10': (ROOT / 'validation/robo/gs10.csv').read_bytes()}
with patch.object(robo_app, 'download_sources', return_value=payloads):
    app = AppTest.from_file(str(ROOT / 'app.py'), default_timeout=30).run()
    assert not app.exception
    app.radio[0].set_value('Personal robo-advisor — Rule B').run()
    assert not app.exception
    assert any('65% stocks / 25% bonds / 10% cash' in item.value for item in app.markdown)
    next(item for item in app.checkbox if item.label == 'Override allocation by hand').check().run()
    assert not app.exception
    assert list(app.dataframe[0].value['Percent']) == ['8.88%', '9.38%', '-28.40%', '-24.41%']
    app.radio[0].set_value('Meridian mandate — Project 2').run()
    assert not app.exception
    assert any('Constrained portfolio' in item.value.to_string() for item in app.table)
print('Both app modes and manual override route successfully.')
