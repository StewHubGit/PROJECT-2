"""Generate real-location manifest, identical Brightspace copies, hashes and ZIP.

Configure delivery.json. Optional --verify-remote checks HTTP accessibility;
it does not certify transcript accuracy or the chronology of a human exercise.
No publishing or course submission is performed by this script.
"""
import argparse
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import shutil
from urllib.parse import quote, urlparse
import zipfile

ROOT = Path(__file__).resolve().parents[1]
SKIP = {'.git', '.venv', '__pycache__', 'tmp'}


def included(path):
    return path.is_file() and not SKIP.intersection(path.relative_to(ROOT).parts) and path.suffix not in {'.pyc', '.pyo'}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--verify-remote', action='store_true')
    args = parser.parse_args()
    config = json.loads((ROOT / 'delivery.json').read_text(encoding='utf-8-sig'))
    repository = config.get('repository_url')
    if repository:
        repository = repository.rstrip('/').removesuffix('.git')
        if not re.fullmatch(r'https://github\.com/[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+', repository):
            raise ValueError('Use the real https://github.com/OWNER/REPO URL.')
        if repository.lower() == 'https://github.com/matvix90/ai-robo-advisor':
            raise ValueError('The reference project is not this submission repository.')
    ref = quote(config.get('ref') or 'main', safe='')
    rows = []

    def add(label, path=None, url=None, note='Prepared; publication not verified'):
        if url is None and repository and path:
            if not (ROOT / path).is_file():
                raise ValueError(f'Missing delivery file: {path}')
            url = f'{repository}/blob/{ref}/{quote(path, safe="/")}'
        rows.append({'part': label, 'path': path, 'url': url, 'note': note})

    add('GitHub repository', url=repository)
    for label, path in [
        ('README and start instructions', 'README.md'),
        ('Decision memo — also attach to Brightspace', 'docs/decision-memo.md'),
        ('Validation/AI use and Locked Changed-Input Record — also attach', 'docs/validation-and-ai-use.md'),
        ('Python web app', 'app.py'),
        ('Point-in-time data card', 'docs/DATA_CARD.md'),
        ('Visible frozen results', 'results/RESULTS.md'),
        ('Personal robo-advisor and selected Rule B', 'robo_app.py'),
        ('Final package verification', 'validation/FINAL_PACKAGE_CHECKS.json'),
        ('Locked Changed-Input Record evidence', 'validation/LOCKED_CHANGED_INPUT_RECORD.md'),
    ]:
        add(label, path)
    commits = [('Prediction commit — before run', 'ai_off_prediction_commit_url'),
               ('Result commit — after first run', 'ai_off_result_commit_url')]
    for label, key in commits:
        url = config.get(key)
        if url and (not repository or not re.fullmatch(re.escape(repository) + r'/commit/[0-9a-fA-F]{7,40}', url)):
            raise ValueError(f'{key} must be a real commit URL in this repository.')
        add(label, url=url, note='Human AI-off exercise/chronology requires evidence')
    for video in config['videos']:
        number = video['number']
        youtube = video.get('youtube_url')
        if youtube and urlparse(youtube).hostname not in {'youtube.com', 'www.youtube.com', 'youtu.be'}:
            raise ValueError('Actual video locations must be YouTube links.')
        add(f'Video {number} — YouTube', url=youtube,
            note='Transcripts enabled per author' if video.get('transcripts_enabled') else 'Recording / enabled transcript PENDING')
        transcript = video.get('transcript_url')
        if transcript and not transcript.startswith('https://github.com/'):
            raise ValueError('Manifest transcript locations must be GitHub links.')
        add(f'Video {number} matched transcript', path=video.get('transcript_path'), url=transcript,
            note='Must match actual recording; scripts are not transcripts')
    add('Submission manifest', 'SUBMISSION_MANIFEST.md')

    remote = {}
    if args.verify_remote:
        import requests

        def verify(url):
            try:
                response = requests.get(url, timeout=(10, 20), allow_redirects=True)
                return url, {'status': response.status_code, 'accessible': response.status_code == 200, 'final_url': response.url}
            except requests.RequestException as error:
                return url, {'accessible': False, 'error': str(error)}

        with ThreadPoolExecutor(max_workers=4) as pool:
            remote = dict(pool.map(verify, sorted({r['url'] for r in rows if r['url']})))
    unresolved = [r['part'] for r in rows if not r['url']]
    ownership_pending = not config.get('ownership_confirmed')
    lines = [
        '# Project 2 submission manifest', '',
        '**DRAFT — not submission-ready.** Missing locations/evidence remain explicitly UNRESOLVED. '
        'A configured URL is not certified until it has been checked. No local path is presented as a submission location.', '',
        '| Part | Submission location | Status |', '| --- | --- | --- |',
    ]
    for row in rows:
        url = row['url']
        location = f'[{row["part"]}]({url})' if url else '**UNRESOLVED**'
        status = row['note']
        if url:
            status += '; HTTP accessible' if remote.get(url, {}).get('accessible') else '; remote verification pending/failed'
        lines.append(f'| {row["part"]} | {location} | {status} |')
    lines += ['',
        'All populated locations above are GitHub links, except the three YouTube video links. '
        'Keep transcripts on GitHub or link them from the repository. Scripts do not satisfy recording/transcript delivery.', '',
        'Brightspace: submit the repository URL and manifest; attach the exact same '
        '`docs/decision-memo.md` and `docs/validation-and-ai-use.md` files. '
        'Do not attach video files. This script prepares files; it does not submit them.', '',
        f'Ownership confirmation: {"PENDING" if ownership_pending else "confirmed in delivery.json"}. '
        'The genuine AI-off prediction/result chronology and actual recordings must be verified separately.', '',
    ]
    (ROOT / 'SUBMISSION_MANIFEST.md').write_text('\n'.join(lines), encoding='utf-8')

    attachments = ROOT.parent / 'Project2_Brightspace_Attachments'
    attachments.mkdir(exist_ok=True)
    copies = {}
    for source in ['docs/decision-memo.md', 'docs/validation-and-ai-use.md', 'SUBMISSION_MANIFEST.md']:
        destination = attachments / Path(source).name
        shutil.copyfile(ROOT / source, destination)
        if sha(destination) != sha(ROOT / source):
            raise ValueError('Brightspace attachment differs from repository file.')
        copies[source] = {'attachment': destination.name, 'sha256': sha(destination)}
    (attachments / 'START_HERE.txt').write_text(
        'These Markdown files exactly match the repository copies.\n'
        'CURRENT STATUS: DRAFT; unresolved GitHub/video locations, AI-off record and ownership confirmation remain.\n'
        'After completing the record and finalizing links/statements, run tools/prepare_delivery.py again.\n'
        'Attach decision-memo.md, validation-and-ai-use.md and SUBMISSION_MANIFEST.md to Brightspace.\n'
        'Use real YouTube links with transcripts enabled; never attach video files.\n', encoding='utf-8')
    audit = {'generated_utc': datetime.now(timezone.utc).isoformat(),
             'submission_ready': False, 'unresolved_locations': unresolved,
             'ownership_confirmation_pending': ownership_pending, 'remote_verification': remote,
             'brightspace_copies': copies,
             'note': 'Human exercise chronology, ownership and actual video/transcript content need separate verification.'}
    (ROOT / 'validation/delivery_audit.json').write_text(json.dumps(audit, indent=2) + '\n', encoding='utf-8')
    files = sorted(p for p in ROOT.rglob('*') if included(p) and p.name != 'SHA256SUMS.txt')
    (ROOT / 'SHA256SUMS.txt').write_text(''.join(f'{sha(p)}  {p.relative_to(ROOT).as_posix()}\n' for p in files), encoding='utf-8')
    archive = ROOT.parent / 'Project2_Final_Ready_For_Review.zip'
    with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as bundle:
        for path in sorted(p for p in ROOT.rglob('*') if included(p)):
            bundle.write(path, path.relative_to(ROOT).as_posix())
    print(f'Prepared {len(rows)} manifest rows; {len(unresolved)} locations UNRESOLVED. Not submission-ready.')
    print(f'Identical Markdown copies: {attachments}')
    print(f'Review package: {archive} ({archive.stat().st_size:,} bytes)')


if __name__ == '__main__':
    main()
