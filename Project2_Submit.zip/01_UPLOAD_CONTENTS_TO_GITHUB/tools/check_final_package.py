"""Check the self-contained package in an independent copy; no network."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile
from urllib.parse import unquote

ROOT = Path(__file__).resolve().parents[1]


def main():
    records = []
    with tempfile.TemporaryDirectory(prefix='project2_final_check_') as temporary:
        isolated = Path(temporary) / 'repository'
        shutil.copytree(ROOT, isolated, ignore=shutil.ignore_patterns('.git', '__pycache__', '.venv', 'tmp'))
        base_python = Path(sys.base_prefix) / ('python.exe' if os.name == 'nt' else 'bin/python3')
        for label, command in [
            ('Frozen source/software replay in isolated base Python', [str(base_python), '-I', '-S', 'run.py']),
            ('Meridian app interactions from independent copy', [sys.executable, 'tools/check_app.py']),
            ('Personal rule, calculations and app controls from independent copy', [sys.executable, '-m', 'unittest', 'test_robo_app', 'test_robo_ui', '-q']),
            ('Combined-mode routing with verified snapshots', [sys.executable, 'tools/check_mode_routing.py']),
        ]:
            completed = subprocess.run(command, cwd=isolated, capture_output=True, text=True, encoding='utf-8', errors='replace', timeout=180)
            records.append({'name': label, 'pass': completed.returncode == 0, 'stdout': completed.stdout, 'stderr': completed.stderr})
            if completed.returncode:
                raise RuntimeError(label + '\n' + completed.stdout + completed.stderr)
        for name in ['checks.json', 'app_checks.json']:
            shutil.copyfile(isolated / 'validation' / name, ROOT / 'validation' / name)
        records.append({'name': 'Independent-copy frozen result equals packaged result', 'pass':
            json.loads((isolated / 'results/result.json').read_text(encoding='utf-8')) ==
            json.loads((ROOT / 'results/result.json').read_text(encoding='utf-8'))})

    links = []
    documents = [ROOT / name for name in ['README.md', 'ROBO_README.md', 'REQUIREMENTS_AUDIT.md', 'SUBMISSION_MANIFEST.md']]
    for directory in ['docs', 'videos', 'validation', 'results']:
        documents += list((ROOT / directory).glob('*.md'))
    for document in documents:
        for target in re.findall(r'\[[^\]]+\]\(([^)]+)\)', document.read_text(encoding='utf-8-sig')):
            if re.match(r'^[A-Za-z]+:', target) or target.startswith('#'):
                continue
            destination = (document.parent / unquote(target.strip('<>').split('#')[0])).resolve()
            # This file is created after the link check.
            exists = destination.is_file() or destination == ROOT / 'validation/FINAL_PACKAGE_CHECKS.json'
            links.append({'document': document.relative_to(ROOT).as_posix(), 'target': target, 'pass': exists})
    records.append({'name': 'Local delivery document links', 'pass': all(item['pass'] for item in links), 'links': links})
    ai_opening = 'I used OpenAI Codex'
    opening_files = ['README.md', 'docs/decision-memo.md', *[f'videos/VIDEO_{n}_{suffix}.md' for n, suffix in [(1, 'HOW_IT_CHANGED'), (2, 'TECHNICAL'), (3, 'COMMITTEE')]]]
    records.append({'name': 'Required two opening statements in README, memo and all scripts', 'pass': all(
        ai_opening in (ROOT / name).read_text(encoding='utf-8-sig').split('\n\n')[0] and
        'The analysis and the decision are mine; education, not investment advice.' in (ROOT / name).read_text(encoding='utf-8-sig').split('\n\n')[1]
        for name in opening_files)})
    records.append({'name': 'Video 3 explicitly opens with app running live', 'pass':
        'FIRST FRAME: the app running live' in (ROOT / 'videos/VIDEO_3_COMMITTEE.md').read_text(encoding='utf-8-sig')})
    report = {'verified_utc': datetime.now(timezone.utc).isoformat(), 'all_pass': all(item['pass'] for item in records),
              'method': 'Independent repository copy; installed dependencies reused for app tests; offline base-Python runner has site packages disabled. No manual browser or fresh dependency installation claimed.',
              'checks': records, 'app_sha256': hashlib.sha256((ROOT / 'app.py').read_bytes()).hexdigest(),
              'human_AI_off_record': 'PENDING', 'publication_and_videos': 'PENDING'}
    (ROOT / 'validation/FINAL_PACKAGE_CHECKS.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
    if not report['all_pass']:
        raise AssertionError(json.dumps([item for item in records if not item['pass']], indent=2))
    print(f"Final package checks: {len(records)}/{len(records)} PASS")


if __name__ == '__main__':
    main()
