# Independent financial model challenge

Read on 2026-11-10: [Federal Reserve SR 26-2](https://www.federalreserve.gov/frrs/guidance/supervisory-guidance-on-model-risk-management.htm), Section V: Conceptual Soundness, Outcome Analysis and Ongoing Model Monitoring. The page identifies the guidance date as April 17, 2026. Footnote 3 excludes generative and agentic AI. Apply these validation ideas to the quantitative finance model and its decision use, not as generative-AI law or a compliance claim.

**What evidence would let an independent reviewer reject or restrict use even when the output looks good?**

| Idea | Reject or restrict on this evidence | Application |
| --- | --- | --- |
| Conceptual soundness | Purpose/design mismatch, unsupported assumptions, inadequate developmental evidence | Historical arithmetic means do not establish five-year real returns; costs/payouts/annual implementation are incomplete; S9 is undefined |
| Outcome analysis | Known-answer failures, material deviations, inappropriate comparisons or unsupported judgment | COST-01 withdraws the net-hurdle interpretation; training answers reproduce, but no prospective or annual-rebalanced realized outcome test exists |
| Ongoing monitoring | Changed inputs/use, unexplained deterioration, untracked limitations or absent responses | 20-point window sensitivity requires input governance; proposal names an owner, vintage/cost/reserve/override records and stop rules |

**Challenger conclusion:** permit educational reproduction; reject live-adoption readiness. A passing software test cannot settle suitability. Before a shadow protocol, require written purpose and loss rules, documented costs, dated inputs and accepted ownership. See [the memo](COMMITTEE_MEMO.md) and [COST-01](../validation/RISKIEST_CLAIM.md).

## Complete local model-risk reference supplied in the handout

Conceptual soundness: the design, assumptions, data, judgments, and developmental evidence must fit the model's stated purpose and intended use.

Outcome analysis: compare results with known or subsequently observed outcomes, baselines, holdouts, backtests, and outliers. An attractive output is not evidence that the process is valid.

Ongoing monitoring: changes in users, data, markets, products, or constraints can make a previously acceptable model unfit. Monitor limitations, performance, overrides, and triggers.

Independent challenge: a reviewer may reject or restrict use when the purpose is mismatched, assumptions or data are unsupported, known-answer/holdout/outcome checks fail, deterioration is unexplained, or monitoring and ownership are absent—even when the output looks polished.

The 2026 guidance expressly leaves generative and agentic AI outside its model definition. Here, apply these validation ideas to the finance model and decision system only.
