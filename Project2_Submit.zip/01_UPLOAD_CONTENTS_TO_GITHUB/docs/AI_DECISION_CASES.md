# AI decision cases and prospective evidence

AI-generated cases on 2026-11-10. Tags identify status, not confidence. **Output:** model/calculation or AI recommendation. **Source:** supplied mandate or saved record. **Assumption:** proposed convention/threshold. **Speculation:** untested possibility. The AI recommendation is not a human AI-off judgment.

## Reject

- **[output]** COST-01 gives 6.33% candidate versus a 6.50% hurdle and 6.72% reference under assumed common costs.
- **[source]** The original lab labels returns historical arithmetic, excludes additional costs and leaves S9 unresolved.
- **[assumption]** Apply a common 25 bp/year drag; taxes are not modeled.
- **[output]** Reject live-adoption readiness: the stated net objective and implementability are not established.
- **[speculation]** Live behavior could disappoint further as costs, data or markets change.

## Redesign

- **[source]** The saved 60-versus-36-month comparison changes SGOV/VT weights by 20.00 percentage points.
- **[output]** The strongest remaining claim is operational: window governance materially affects a proposed allocation.
- **[assumption]** Redefine the next hypothesis as reproducible, timely, cost-documented and reserve-compliant decision production, without an excess-return promise.
- **[output]** Recommend REDESIGN with $0 live capital; no new retrospective analysis in this submission.
- **[speculation]** Fixed protocols and approvals may reduce overrides or surprise trading; that benefit is unmeasured.

## Tightly bounded pilot

- **[assumption]** After written committee approval only: $1,000,000 shadow notional, $0 live, 12 months starting with the first approved complete monthly interval.
- **[assumption]** Proposed owner Sam Stewart must accept monitoring responsibility.
- **[assumption]** Monthly audit covers receipts, vintage availability, costs, allocation changes, exceptions and turnover; a future implementation checks reserves daily.
- **[assumption]** Kill on a missing required vintage, unexplained source mismatch, reserve below 3%, unapproved annual turnover above 25%, or the approved loss-rule breach.
- **[source]** S9's undefined loss measure prevents approving a complete loss kill rule today.
- **[output]** Do not authorize the trial yet; it is conditional redesign work.
- **[speculation]** Successful operations could justify another review, but cannot establish five-year returns.

## Minimum prospective evidence

- **[assumption]** Before collection: signed CIO priority and S9 definition, approved cost/rebalancing conventions, starting holdings, reserve eligibility and override handling.
- **[assumption]** Freeze code, decision rules, baseline, cost fields, timestamps and gates before the first observation. A later version preserves rather than replaces failed records.
- **[assumption]** Collect 12 monthly packets with then-available source snapshots, reproducible calculations, next-session execution assumptions, independent reconciliations and exception logs; $1,000,000 notional, $0 live.
- **[assumption]** Operational gates: 12/12 packets reproducible and on time, zero look-ahead substitutions or unapproved overrides, no reserve/turnover/loss-rule breach, and documented costs within a committee-approved budget. The current 25 bp assumption is not an approved budget.
- **[output]** Twelve months can test operations; it cannot validate rolling five-year CPI+4.
- **[assumption]** A reopened return hypothesis needs an untouched outcome protocol, actual CPI, distributions, annual rebalancing, payouts and full costs, plus at least 60 prospective monthly returns for one five-year outcome; one window alone does not establish reliability.
- **[output]** None of that prospective evidence is claimed here. No new analysis is added to this frozen submission.

## Human decision boundary

**[output]** Codex's draft recommendation is REDESIGN. **[source]** The studio asks Sam to close AI and make his own recommendation. **[output]** That personal decision remains pending; do not represent the draft as an independently completed AI-off exercise.
