# Project 2 data card

| Field | Frozen record |
| --- | --- |
| Purpose | Reproduce an ETF allocation lab and test its modeled return interpretation under one cost assumption |
| Universe | SGOV, IEF, BND, VT; USD adjusted prices |
| Source | Saved Yahoo Finance chart API daily JSON; [requests and receipts](../evidence/fund_prices_sources/sources.json) |
| Acquisition | 2026-10-22, with per-fund UTC timestamps in receipts |
| Measured period | 2021-09-30 through 2026-09-30; 61 prices, 60 monthly returns |
| Transform | Last adjusted close per completed month; simple return P(t)/P(t-1)-1; arithmetic mean x12; sample covariance x12 |
| Volatility | Sample standard deviation x sqrt(12); scaling assumes no serial correlation |
| Distributions and expenses | Embedded in adjusted prices; do not add them again |
| Additional costs | Assumed common 25 bp annual drag in COST-01; no verified advisory/trading bill; taxes not modeled |
| Missing values | No filling; nonpositive/nonfinite values, duplicate/out-of-order months and gaps fail validation |
| Revision risk | Adjusted history can change after later events or vendor corrections; original JSON and hashes retained |
| Eligibility | Only SGOV is reserve-eligible in the ETF exercise; a conservative lab proxy, not live dealing verification |
| Reserve | $0.75m quarterly x4 / $100m = 3%; 5-point search grid requires at least 5% when a positive reserve is needed |
| Target | 6.50% = assumed CPI 2.50% + 4 percentage points; actual rolling CPI and net outcomes not supplied |
| Tradability | Not established: snapshot acquired after the sample; no full trade-level vintage ledger exists |

## Point-in-time rule

### App signal, added 2026-11-17

`review.py` computes a **20-observation change in DGS10** from a single saved eligible vintage: `(latest yield - yield 20 nonmissing observations earlier) * 100`, in basis points. The 2026-09-30 vintage contains 2026-08-31 at 4.75% and 2026-09-29 at 5.26%, producing **+51.00 bp / RISING**, for a proposed **2026-10-01** review. Weekends and missing values are not filled; this is 20 observations, not 20 calendar days.

The saved snapshot was downloaded on 2026-10-29. Historical ALFRED vintage reconstruction supports the information-set demonstration, not a claim that a trade or receipt occurred in September. The signal provides rate context and a data-admission gate, with no demonstrated predictive value and no effect on ETF weights. A required-vintage failure yields **QUARANTINE / STOP**; there is no fallback to current history. The app's availability checkbox demonstrates that failure path. These dates and the card are frozen historical evidence, not a current signal service.

The ETF estimator remains retrospective and is not made point-in-time by this separate signal. Its historical prices were acquired 2026-10-22. This limits the process to research/redesign under the current recommendation.

For prospective DGS10 use, select the ALFRED vintage dated the previous calendar day; trade only in the next actual session. Both observations in a computed change must exist in the same eligible vintage. Retain measurement date, vintage date, receipt timestamp and trade date. Skip a signal when its required vintage is unavailable; never substitute today's history. This is a conservative date-level rule, not proof of intraday release time.

The saved Lab 17 comparison shows that the **2026-09-30** vintage ends at **2026-09-29, 5.26%**, with **19** later arrivals and **zero** revisions on shared dates versus the saved 2026-10-29 download. These facts do not certify every historical portfolio trade. The allocation engine consumes **no DGS10 signal**. [Full Lab 17 card](../labs/17_fred_asof/DATA_CARD.md).

Lab 16 uses a supplied teaching table, not market securities; its publication-date filter is a known-answer check. [Its source limitations](../labs/16_point_in_time/DATA_CARD.md) remain intact.

Lab 18/19 SEC snapshots use separate fiscal dates, filing cutoffs and acquisition dates. Lab 19's cutoff is **2026-11-05**; it provides company-research support only. It cannot certify the historical ETF allocation or an investable price. Missing values remain unknown.
