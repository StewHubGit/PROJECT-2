**AI use:** I used OpenAI Codex to help implement the apps, check calculations, assemble evidence, and draft the memo and video scripts.

**Ownership statement — pending Sam's review and confirmation:** “The analysis and the decision are mine; education, not investment advice.”

# Validation and AI use

Prepared November 23, 2026. Reproduced software results do not establish
investment suitability or complete the outstanding human/delivery requirements.

## What was checked

| Work | Evidence | Interpretation |
| --- | --- | --- |
| Frozen Meridian source/calculation replay | [checks](../validation/checks.json); `python run.py` | Source hashes, original lab files and results reproduce. COST-01 remains a financial claim failure. |
| Meridian app interactions | [app checks](../validation/app_checks.json); `python tools/check_app.py` | Baselines show rule-specific verdicts; cost/window controls work; missing vintage halts allocation output. |
| Personal Rule B and loss calculations | `python -m unittest test_robo_app test_robo_ui -v` | Age bounds, reaction caps, cash override, manual switching, monthly parsing/rebalancing, initial-wealth drawdown and loss grid. |
| Fresh public-data acceptance | [result/source hashes](../validation/robo/acceptance.json) | Supplied 60/40/0 benchmark and all four allocation probes match. Disclosed AI-assisted acceptance tests. |
| Independent-copy package check | [final verification](../validation/FINAL_PACKAGE_CHECKS.json) | Recorded after execution; AI-assisted software checks, not a human review or prediction. |

The Meridian candidate is 65% SGOV / 35% VT. Under an assumed common 25 bp
annual drag, its 6.58% historical arithmetic estimate becomes 6.33%, below
the 6.50% planning hurdle and 6.72% reference estimate. The reference lacks
the selected reserve. No retuning repairs the frozen failed claim.

The separate personal mode uses US market/cash returns from monthly French
factors and a constant-ten-year Treasury approximation from GS10. Its 60/40/0
acceptance case has 432 months, 8.88% CAGR, 9.38% volatility, −28.40% drawdown,
and −24.41% worst 12 months ending February 2009 (−$24,415 on $100,000).
Bonds alone lose 16.87% in the 12 months ending October 2022. At a 20% limit
and no cash, 50% is the largest passing stock share on the 10% grid. At 15%,
no zero-cash mix passes; 20% cash permits 30% stocks; 10% cash permits no mix.
Historical screens cannot guarantee future loss limits.

## Completed AI-assisted changed-input example for the videos

The [completed COST-01 record](../validation/AI_ASSISTED_CHANGED_INPUT_RECORD.md)
documents the existing retrospective AI-assisted test: cost 0 → 25 bp with
weights/data fixed; candidate estimate 6.58% → 6.33%, below the 6.50% hurdle;
independent Decimal reproduction; decision REDESIGN with $0 live. The videos
may show this completed evidence now. It does not complete the distinct
AI-off precommit requirement below.

## Locked Changed-Input Record — PENDING

**The required exercise has not been completed or certified.** Codex has not
written Sam's prediction, run an undisclosed prospective test for him, or
represented a local/replayed test as a pre-run GitHub prediction.

| Required field | Current record |
| --- | --- |
| App mode and version/commit | PENDING — choose Meridian mode for this mandate-verdict exercise |
| One precise input, old value and new value | PENDING — Sam chooses after closing AI |
| All other controls and source hashes fixed | PENDING |
| Sam's AI-off prediction, direction/range and reasoning | PENDING — Sam's own words |
| Expected mandate verdict and what would change the recommendation | PENDING |
| Prediction committed to GitHub before execution | PENDING — real commit URL/SHA, timestamp, visible committed file |
| Baseline and first changed-input run | PENDING — timestamp, exact controls, source/app hashes and retained output |
| Actual versus prediction | PENDING |
| Effect on mandate verdict and recommendation | PENDING |
| Later GitHub result commit | PENDING — after the prediction commit and first run |
| Assistance after locking the prediction | PENDING — disclose truthfully |

Follow the [precommit protocol](../validation/AI_OFF_PRECOMMIT_PROTOCOL.md).
The [historical COST-01 replay](../validation/COST01_RETROSPECTIVE_REPLAY.md),
supplied personal benchmarks and disclosed stress settings are **ineligible**
substitutes. Avoid already disclosed settings for the prospective test. Preserve
an adverse first result and the original prediction; do not edit history or tune
the test until it passes.

The [separate record](../validation/LOCKED_CHANGED_INPUT_RECORD.md) tracks the
same pending exercise. After completion, update both with the same evidence
and real GitHub commit links. Local commits alone do not meet the requirement.

## AI contribution, human choices and one checked output

OpenAI Codex assisted with code, numerical checks, packaging and draft prose.
No runtime LLM chooses weights. The personal allocation is **option B selected
by Sam from AI-proposed options**: stocks start at 100 minus age, bounded
0%–80%; cash/reaction adjustments and the one-year cash override are code.
Sam selected the rule; the formula was AI-proposed.

One AI interpretation checked was whether Meridian's gross estimate clearing
6.50% supported readiness. Holding original data/weights fixed, the assumed-
cost test removes that clearance. Independent Decimal arithmetic reproduces
the failure. The consequence is to withdraw live-use readiness, rather than
equating a passing software test with a passing investment claim. Sam must
review the first-person reflection before using it as his own.

Codex previously filled the named reviewer role as an explicitly disclosed AI
stand-in. No Pete participation or independent human AI-off review is claimed.
Scripts are preparation, not actual videos or matched transcripts.

## Point-in-time and mandate limits

[Data card](DATA_CARD.md): a saved September 30 DGS10 vintage contains the
September 29 measurement before a proposed October 1 review. Its 20-known-
observation yield change is +51 bp. It is historical context/data admission,
not an allocation signal. Missing required vintage halts allocation output
with no current-history fallback.

The ETF history and personal-mode revised French/GS10 history are retrospective.
A separate saved-vintage signal does not make either a tradable historical
strategy. Costs are assumptions, taxes unmodeled, and S9's definition, annual
turnover/path and actual rolling CPI outcomes remain unresolved. Full mandate
clearance is not claimed.

## Publication, videos and ownership

GitHub repository/file URLs remain **UNRESOLVED** until published and verified.
Videos 1–3 must be actual YouTube recordings with transcripts enabled; Video 3
opens on the app running live. Attach/link matched transcripts in the repo.
No video URL, transcript or human confirmation is invented. [Manifest](../SUBMISSION_MANIFEST.md).
