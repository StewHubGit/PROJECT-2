**AI use:** I used OpenAI Codex to help implement the apps, check calculations, assemble evidence, and draft the memo and video scripts.

**Ownership statement — pending Sam's review and confirmation:** “The analysis and the decision are mine; education, not investment advice.”

# Meridian committee decision

**To:** Meridian Investment Committee | **From:** Sam Stewart | **Date:** 2026-11-10

**[output] Recommendation: reject current live use; REDESIGN; $0 live capital.** Preserve the failed net-hurdle claim and the original allocation. Do not adopt the ETF mix or replace it with the higher-return reference on this evidence.

**[source] Mandate and record.** The $100m case requires a $3m payout reserve (3%) and seeks CPI+4% net over rolling five-year periods. The 6.50% nominal hurdle assumes 2.50% CPI. S9's 10% calendar-year loss measure and response remain undefined. Prices span 2021-09-30 to 2026-09-30: 61 adjusted-price observations, 60 returns, acquired 2026-10-22.

**[output; cost assumption] Failed result.** The frozen 65% SGOV / 35% VT mix has a 6.58% annualized arithmetic estimate and 5.29% sample volatility. COST-01 applies an assumed common 25 bp annual drag: candidate **6.33%**, hurdle **6.50%**, 60% VT / 40% BND reference **6.72%**. Candidate lag to reference is **38.99 bp**; cost headroom is only **7.81 bp**. Independent Decimal arithmetic reproduces the failure. These are in-sample estimates, not realized after-cost returns; taxes are unmodeled. The reference has no SGOV reserve and fails that screen. No retuning was performed.

**[output] Allocation range.** 0%-0% live ($0-$0) of the $100m mandate; conditional shadow range $0-$1,000,000 notional. No shadow approval today.

**[output] Strongest supported claim.** The existing switch from 60 to 36 estimation months moves 20.00 percentage points from VT to SGOV. Window choice needs an approval rule before it drives trades. **[speculation]** Such governance may reduce avoidable turnover; the benefit is untested.

**[output] App and diagnostics, updated 2026-11-17.** Equal weight and 60/40 receive same-rule verdicts. Separate estimate, window, cost and severe reserve stresses preserve the frozen candidate. Saved DGS10 rises 51 bp over 20 known observations through 2026-09-29 in the 2026-09-30 vintage; proposed review 2026-10-01. Missing vintage stops the process. This context does not set weights. The retrospective COST-01 replay does not meet the AI-off GitHub precommit requirement; that record is pending.

**[output] Three claims we cannot make:** (1) excess realized return after costs; (2) five-year CPI+4 or protection against loss above 10%; (3) stable out-of-sample allocations or historically tradable signals without look-ahead.

**[output] Alternatives.** Reject current live use because purpose and evidence do not match. Redesign around operational reliability. A bounded shadow pilot is an alternative only after the missing approvals; no pilot is authorized today.

**[assumption] Minimum prospective protocol.** First obtain the CIO's written objective and S9 rule, cost documentation, starting holdings and a frozen point-in-time protocol. Propose **$1,000,000 shadow notional, $0 live, 12 months** from the first approved complete monthly interval. Require 12/12 timely, reproducible packets, saved then-available sources, reconciled costs and zero unapproved overrides or mandate breaches. Twelve months tests operations; a return claim needs at least 60 untouched monthly outcomes with actual CPI, payouts, rebalancing and full costs, plus evidence of reliability.

**[assumption] Monitor and reversal.** Proposed owner **Sam Stewart**, subject to acceptance, audits sources/vintages, costs, allocation changes and exceptions monthly; future implementation checks reserves daily. Kill on a missing required vintage, unexplained source mismatch, reserve below 3%, unapproved turnover above 25%, or approved loss breach. Reverse REDESIGN to a separately approved shadow protocol only when written conditions are met; live use needs another committee decision.

**Evidence:** results/result.json; validation/RISKIEST_CLAIM.md; validation/checks.json; docs/AI_DECISION_CASES.md. **Human AI-off review/sign-off: pending.**


## Submission update — November 23, 2026

The main app now exposes Meridian mandate mode and a separately labeled personal robo-advisor mode. Sam selected age-based option B from AI-proposed options. Its US-stock/Treasury-approximation/cash universe, monthly rebalancing and 1990–2025 window differ from the Lab 13 global ETF mandate; its historical results do not validate the Meridian recommendation. The frozen Meridian prices, allocation and COST-01 failure are unchanged.

Missing required vintage now actually halts allocation calculations. The [validation and AI-use report](validation-and-ai-use.md) includes the explicitly pending Locked Changed-Input Record. A prediction authored with AI closed and committed to GitHub before an unrun change, actual YouTube recordings with enabled transcripts, and personal ownership confirmation remain required.
