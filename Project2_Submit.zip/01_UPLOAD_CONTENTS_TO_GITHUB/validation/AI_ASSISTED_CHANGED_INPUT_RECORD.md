# AI-assisted changed-input test — COST-01

**Completed retrospective analysis, prepared with OpenAI Codex assistance.**
This is the existing disclosed cost test, not a new human prediction or AI-off
precommit exercise. Original source data and frozen results remain unchanged.

| Field | Completed record |
| --- | --- |
| Purpose | Check whether the frozen candidate clears the planning hurdle after an additional cost assumption |
| App mode | Meridian mandate — Project 2; Saved Project 2 funds |
| Changed input | Additional annual cost drag: **0 → 25 basis points** |
| Assumption | 25 bp = 0.25 percentage points annually; not a measured fee quote |
| Fixed candidate | **65% SGOV / 0% IEF / 0% BND / 35% VT**; no retuning |
| Fixed reference | **60% VT / 40% BND**; same additional cost |
| Fixed data | 61 prices, 60 monthly returns; September 2021–September 2026 |
| CSV SHA-256 | `6e3ea0aaf5d07a81e0453cadf71129ff85c60466c003ce21e1d661b1addfa9bc` |
| Fixed screens | 6.50% net planning hurdle; 3% selected SGOV reserve minimum |
| Retrospective AI-assisted expectation | Candidate misses 6.50% after the drag; not an unseen human prediction |
| Candidate before cost | **6.5781%**, displayed **6.58%** |
| Candidate after cost | **6.3281%**, displayed **6.33%** |
| Reference after same cost | **6.7180%**, displayed **6.72%** |
| Cost headroom | **7.81 bp** |
| Candidate versus reference | **−38.99 bp**; reference separately fails reserve screen |
| Modeled verdict | **FAIL: net planning hurdle** |
| Verification | Independent Decimal calculation matches; 39/39 source/software checks pass |
| Decision consequence | **REDESIGN; $0 live capital** |
| Preserved | Original data and weights; gross zero-additional-cost result retained |
| AI involvement | Codex assisted with test specification, checks, interpretation and documentation |
| Human AI-off pre-run GitHub prediction | **Not performed or supplied** |

Recording wording: “This is an AI-assisted retrospective changed-input test.
It demonstrates the calculation and decision consequence. The separate AI-off
precommit requirement remains incomplete.”

[Original retrospective record](COST01_RETROSPECTIVE_REPLAY.md) ·
[Calculation trace](RISKIEST_CLAIM.md) · [Result](../results/result.json) ·
[Checks](checks.json).
