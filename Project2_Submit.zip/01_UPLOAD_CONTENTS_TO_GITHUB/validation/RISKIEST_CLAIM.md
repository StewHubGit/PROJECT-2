# Riskiest claim and one concrete test

**Original risky interpretation:** the selected 65% SGOV / 35% VT mix is ready for a pilot because its 6.58% estimate clears Meridian's 6.50% return target. The original lab actually cautions that costs are excluded and S9 is undefined; an unconditional suitability claim would exceed that evidence.

**AI-proposed concrete test COST-01:** freeze that allocation, its 60-return sample, the 6.50% target, SGOV reserve eligibility and the original 60/40 reference. Change only the additional annual cost input from 0 to **25 basis points**, subtract the same assumed drag from both arithmetic estimates, and ask whether the candidate still clears the hurdle and beats the reference. Do not reoptimize, change the window, or tune the cost to get success.

25 bp is an **assumption**, not a fee quote or measured implementation cost. It is one transparent falsification case. Fund expenses already enter adjusted prices; taxes are not modeled. The more general diagnostic is the candidate's **7.81 bp** cost headroom, calculated directly from the frozen gross estimate minus the hurdle.

| Evidence | Result |
| --- | --- |
| Candidate gross annualized arithmetic estimate | 6.578122504617309% |
| Candidate minus assumed 0.25 percentage-point drag | 6.328122504617309% |
| 60% VT / 40% BND gross arithmetic reference | 6.968022806229243% |
| Reference minus same assumed drag | 6.718022806229243% |
| Candidate versus reference | -38.99 bp |
| Additional-cost headroom above 6.50% hurdle | 7.812250461730896 bp |
| Claim outcome | FAIL under this cost assumption |

**Independent check:** `run.py::validate` uses Decimal arithmetic, the prior saved unrounded fund means, and prior fixed weights. It does not call the optimizer or its weighted-return helper for this calculation. It checks the net failure against the engine result. A passing reproduction test confirms that the adverse result remains visible; it does not make the financial claim pass.

**Repair:** drop readiness for live adoption and qualify the result as a reproducible in-sample allocation calculation. The strongest supported operational claim is that the existing estimator-window switch changes SGOV/VT weights by **20.00 percentage points**. This reveals a governance need to control input windows and approval of resulting trades; it does not prove better performance. The 60/40 reference's 0% SGOV also fails the selected reserve constraint.

**Three claims the evidence cannot support:**

1. The process beats its baseline after realized trading costs, tax and fees.
2. It achieves rolling five-year CPI+4 net returns or prevents a calendar-year loss above 10%.
3. Its historical decisions were tradable without look-ahead or its allocation is stable out of sample.

## Source -> transformation -> test -> decision

1. [Daily source receipts](../evidence/fund_prices_sources/sources.json) identify Yahoo adjusted-close fields, UTC acquisition times on 2026-10-22, exact request URLs and hashes. Corresponding raw JSON files are alongside them.
2. [61 monthly prices](../data/prices.csv) cover 2021-09-30 through 2026-09-30. The runner checks every CSV cell against the saved daily source's month-end adjusted observation.
3. [Original estimates](../evidence/fund_estimates_original.json) preserve sample means, volatilities, covariance and the CSV hash. [The engine](../portfolio.py) creates 60 simple returns, annualizes mean and sample covariance, and searches the 5-point grid.
4. [Original app record](../evidence/window_comparison_original.json) freezes 65/0/0/35 and the 85/0/0/15 window stress. No new search specification was selected for this test.
5. [COST-01 implementation](../run.py) and [checks](checks.json) reproduce the numbers and claim failure; [the changed-input record](LOCKED_CHANGED_INPUT_RECORD.md) discloses the retrospective AI-assisted process.
6. [The committee memo](../docs/COMMITTEE_MEMO.md) recommends REDESIGN, $0 live capital, and a prospective operational protocol with conditions and stop rules.

This is not a strategy performance backtest. A weighted arithmetic mean describes constant-weight one-period exposure; it does not implement annual rebalancing or the payout path. The comparison cannot establish actual after-cost failure or risk-adjusted dominance. No new realized-performance analysis is added under the scope freeze.
