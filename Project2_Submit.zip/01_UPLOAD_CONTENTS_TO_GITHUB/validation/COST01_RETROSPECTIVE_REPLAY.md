# Locked Changed Input Record

**Frozen 2026-11-10. Author: Codex with Sam Stewart. Reviewer role: Pete, filled by Codex as an AI stand-in at Sam's request.**

**Process disclosure:** retrospective, AI-assisted controlled replay. The arithmetic had been inspected before this record was written. This is not a blind preregistration, an AI-off human test, or a record of Pete's participation. The file locks the replay specification and failed result for this delivery; Git history and package hashes document the delivered version.

| Field | Locked value |
| --- | --- |
| Claim | The frozen mix clears the mandate's net return hurdle and supports pilot readiness |
| One changed input | Additional annual cost drag: 0 -> 25 bp |
| Unit/convention | 25 bp = 0.25 percentage points = 0.0025 decimal annual drag |
| Source status of changed input | Assumption; no fee quote or realized-cost evidence supplied |
| Fixed prices | `data/prices.csv`, SHA-256 `6e3ea0aaf5d07a81e0453cadf71129ff85c60466c003ce21e1d661b1addfa9bc` |
| Fixed sample | 60 monthly returns from 61 prices, 2021-09-30 through 2026-09-30 |
| Fixed candidate | SGOV/IEF/BND/VT = 65/0/0/35%; no reoptimization after cost |
| Fixed reference | 0/0/40/60%; same common additional cost |
| Fixed hurdles | Return 6.50%; SGOV reserve minimum 3% |
| Prediction used for replay | Candidate misses 6.50% after 25 bp and remains below the reference |
| Observed | 6.33% candidate; 6.72% reference; -38.99 bp relative; 7.81 bp cost headroom |
| Check | Independent Decimal arithmetic versus original means and frozen weights matches |
| Financial verdict | FAIL under stated assumption; realized performance remains untested |
| Repair | Withdraw pilot-readiness interpretation; REDESIGN with $0 live capital |
| Restore | No original input/source files edited; 0-cost gross result remains 6.58% |
| Scope lock | No new assets, optimization settings, data refresh, cost search or strategy backtest |

Run `python run.py`. [Result](../results/result.json), [checks](checks.json), and [source-to-decision trail](RISKIEST_CLAIM.md) retain the adverse outcome.

**Human review pending:** Sam must review the recommendation with AI closed and record his own final decision before submission if the course requires that personal step. Codex cannot attest to an unobserved human exercise.
