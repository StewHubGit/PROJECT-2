# Locked Changed-Input Record

**PENDING - requirement not satisfied.**

The existing COST-01 record is an explicitly retrospective AI-assisted replay, not an AI-off prediction committed to GitHub before the run. Its original text is preserved in [COST01_RETROSPECTIVE_REPLAY.md](COST01_RETROSPECTIVE_REPLAY.md); the failed outcome remains visible.

Use [the precommit protocol](AI_OFF_PRECOMMIT_PROTOCOL.md). Do not insert a fabricated prediction, backdate a commit, or reuse the disclosed result as an unseen test.

| Required evidence | Status |
| --- | --- |
| Sam's AI-off prediction in his own words | PENDING |
| Exact single changed input and fixed controls | PENDING |
| GitHub commit URL containing the prediction before execution | PENDING |
| First-run time, command, output and input/source hashes | PENDING |
| Observed versus predicted result and decision consequence | PENDING |
| Later result commit and comparison with baseline | PENDING |
