# Human AI-off prediction and GitHub precommit

For detailed GitHub steps, baseline capture, timestamps, screenshots and later
recording directions, use [the handoff guide](../FINISH_AND_RECORD.md).
Blank worksheets: [prediction](templates/AI_OFF_PREDICTION_TEMPLATE.md) and
[result](templates/AI_OFF_RESULT_TEMPLATE.md). They contain no selected test
input, substantive prediction or completed human attestation.

This step must be completed by Sam. Codex cannot write Sam's prediction or attest that AI was closed. The already disclosed COST-01 replay is ineligible for this requirement.

1. Publish the prepared repository to the intended GitHub repository. Keep the existing failure and AI disclosures.
2. Close AI. Choose one previously unrun input change in the app. Avoid the documented costs, windows, estimate and reserve stress settings whose outcomes are already disclosed. Keep all other controls fixed. Record the precise old/new values, your predicted direction or range, expected mandate verdict, reasoning, and what would change your decision. Do not run the change yet.
3. Create `validation/ai_off_prediction.md` on GitHub containing your own words and a truthful AI-off authorship statement. Commit it. Save the commit URL and SHA. Verify the committed file is visible on GitHub **before** the run. A local file, local commit or retrospective note does not meet this requirement.
4. Start from the saved-price default. Record a timestamp and baseline screenshot. Change only the locked input, run once and save the first result, exact control values, app/source version and timestamps. Do not replace an adverse result or tune the test until it passes.
5. Append actual versus prediction, mandate and recommendation changes, and restore the original controls. Commit the evidence in a later commit. Link both commits in `LOCKED_CHANGED_INPUT_RECORD.md` and the manifest. Record any assistance after the prediction was locked separately.

The app intentionally performs only its published diagnostics during startup. Do not select your prospective test until AI is closed; do not give Codex a value to investigate before you commit your own prediction. The procedure is prepared; no successful human exercise is claimed.
