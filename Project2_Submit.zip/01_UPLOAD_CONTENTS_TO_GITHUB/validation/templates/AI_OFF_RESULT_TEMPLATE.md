# Blank worksheet — not a completed run

After the prediction precommit and first run, create
`validation/ai_off_result.md`. Fill this from actual evidence; do not alter the
prediction file. Delete these worksheet instructions from the completed file.

## Chronology and inputs

- Prediction commit URL/SHA and commit time: [record]
- Immutable prediction-file URL: [record]
- App code version/commit and data hashes: [record]
- Baseline captured at, including timezone: [timestamp]
- First changed-input run at, including timezone: [timestamp]
- One changed control, old → new and units: [record]
- Exact other controls held fixed: [record]
- Any unintended intermediate runs or deviations: [record honestly]
- Baseline and first-result screenshot/output links: [record]

## Actual first result

- Current allocation: [actual]
- Gross and net annual estimate: [actual or unavailable]
- Volatility and reserve: [actual or unavailable]
- Mandate verdict and rule(s): [actual]
- Stop/infeasibility message, if any: [actual]

## Comparison and decision

- Prediction versus observation: [compare honestly]
- Explanation of agreement/difference: [your reasoning]
- Mandate-verdict consequence: [record]
- Recommendation consequence, including no change if appropriate: [your decision]
- Defaults restored after retaining first result: [time/status]
- AI or other assistance after prediction was locked: [disclose]

Commit this result/evidence in a later GitHub commit. Keep that commit URL/SHA
separately, then link both commits in the required validation report and locked
record. A result commit time is not a substitute for the actual run timestamp.
