# Blank worksheet — not a completed prediction

After closing AI, create `validation/ai_off_prediction.md` on GitHub and fill
these headings yourself. Do not commit this blank worksheet as the prediction.
Do not run the changed input until your completed prediction is committed and
visible on GitHub. Delete these worksheet instructions from the completed file.

## Authorship and timing

- Instructions/blank template: prepared with Codex before the independent session.
- Prediction and reasoning author: [your name]
- Truthful statement that AI was closed while choosing/writing the prediction: [your words]
- Prediction written at, including timezone: [timestamp]
- Published code version/commit URL: [GitHub URL]
- Data/source hashes: [hashes]

## Baseline and one change

- App mode and input source: [record]
- Baseline screenshot/evidence: [path or link]
- Input label: [one exact control]
- Old value and units: [record]
- New value and units: [record]
- All other controls, including means/reserve eligibility/window/cost: [record exact fixed state]
- Why this is a previously unrun, undisclosed change: [your words]

## My prediction — complete before the run

- Expected direction or range for the portfolio result: [your prediction]
- Expected allocation change or no change: [your prediction]
- Expected mandate verdict and which rule: [your prediction]
- Why I expect this: [your own reasoning]
- Result that would change my recommendation: [your own criterion]

The GitHub commit containing this completed file is the prediction precommit.
Keep its commit URL/SHA separately; do not edit the prediction after the run.
