# README-only cold run

**PASS. Reviewer: Codex filling Pete's role as an AI stand-in at Sam's request. Pete did not perform this run.**

Observed 2026-11-17T19:09:19.167057+00:00. Copied the complete repository into a temporary independent directory, excluded Git/cache/virtual-environment files, and ran the root entry point with the base Python interpreter and site packages disabled. No sibling course folder or installed Streamlit package was available to the script.

README command: `python run.py`. Cold-run strengthening: `python -I -S run.py`. The extra flags disable Python environment/site-path assistance; the entry point and inputs are identical.

Exit code: 0. Reproduction checks: 39/39 PASS. Result JSON matches the submitted result exactly.

```text
AI announcement: Prepared with OpenAI Codex assistance; education, not investment advice.
Reproduction checks: 39/39 PASS
COST-01 financial claim: FAIL (preserved); committee action: REDESIGN; live capital: $0
Candidate: 65% SGOV / 35% VT; gross estimate 6.58%; after assumed 25 bp: 6.33%
60/40 reference after same assumed cost: 6.72%; target: 6.50%
Existing 60-to-36-month window stress: 20.00 percentage-point largest weight change
Open results/RESULTS.md or results/RESULTS.html. See docs/COMMITTEE_MEMO.md and videos/.
```

**Scope:** software/source replay only. COST-01 remains a failed financial claim under an assumed cost drag. The run does not establish live tradability, forecast quality, annual-rebalanced realized performance or Pete's independent judgment.

The required Python web app was checked separately with Streamlit AppTest; see [app checks](app_checks.json). The one-page memo was rendered and visually inspected. Human AI-off prediction, prior GitHub commit and recommendation/sign-off remain pending.

**Assignment alignment, 2026-11-17:** Sam supplied the eight base requirements. Added same-control baseline verdicts, saved-vintage DGS10 context and quarantine, isolated estimate/constraint diagnostics, explicit allocation range, required memo path and pending ownership declarations. Original prices, candidate and COST-01 failure remain unchanged. The historical replay is preserved separately and does not qualify as the required human AI-off precommit. No original lab file was edited. The archived Lab 18 rule suite requires optional dependencies and remains outside this standard-library replay.
