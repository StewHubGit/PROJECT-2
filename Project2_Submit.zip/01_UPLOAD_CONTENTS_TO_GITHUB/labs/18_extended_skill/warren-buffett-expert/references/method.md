# Method and provenance

Framework: CinderZhang/FAskills, `financial-researcher/experts/warren_buffett.md`, commit `8d5e14fc44df57cd37fdc5f041e43d773e37c196`, inspected 2026-11-03. [Pinned source](https://github.com/CinderZhang/FAskills/blob/8d5e14fc44df57cd37fdc5f041e43d773e37c196/financial-researcher/experts/warren_buffett.md).

The adaptation retains the six areas: business understanding, moat, management, owner earnings, intrinsic value and margin of safety. It replaces model arithmetic with deterministic Python, allows missing evidence, and uses simulated educational judgments. News, insider data and Berkshire holdings are outside the keyless 10-K calculation pipeline.

Data: [SEC API documentation](https://www.sec.gov/search-filings/edgar-application-programming-interfaces) and [fair-access guidance](https://www.sec.gov/about/developer-resources). Public submissions and companyfacts need no API key. Downloads identify the requester, run serially at most four requests/second per process, and save timestamps and SHA-256 receipts. Multiple independent processes still share SEC's per-user limit. Transient HTTP failures have at most three attempts; HTTP 403 stops the run.

Selection: retrieve at most six annual original 10-Ks filed on or before the cutoff. Use the newest five for cash history and the sixth only to locate opening equity. For each fiscal year, require its own original filing accession, exact report end and supported USD US-GAAP entity-wide tag. Flow facts require a 330–400-day annual period. Shares require the `shares` unit. Instant facts require no start date. Conflicting contexts are null, not guessed. No 10-Q, 10-K/A or later restatement is substituted. Tag preference is explicit in `scripts/buffett.py`. The cutoff is a filing-date filter (end of that date), not an intraday trading timestamp. Current companyfacts is not a historical API vintage; preserve the raw extract when replaying.

All amounts remain dollars/shares in JSON. UI scaling to millions/billions is performed by code. Ratios are fractions in JSON, converted to percentages by the app. Missing facts are null. Ratios require a positive denominator. ROE also requires positive opening and closing equity, both from the selected filing.

| Calculation | Definition |
| --- | --- |
| Owner cash proxy | Operating cash flow minus total property, plant and equipment cash spending |
| Owner cash per diluted share | Proxy / annual weighted-average diluted shares |
| Net margin | Net income / revenue |
| Operating margin | Operating income / revenue |
| Return on average equity | Net income / arithmetic mean of opening and closing equity |
| Liabilities/assets | Total liabilities / total assets; includes non-debt liabilities |
| Cash conversion | Operating cash flow / positive net income |
| Capital intensity | Capital spending / revenue |
| Stock compensation intensity | Share-based compensation / revenue |
| Reported long-term debt incl. current maturities | LongTermDebtCurrent + LongTermDebtNoncurrent; no missing component filled with zero |

This debt subtotal excludes separate short-term borrowing, commercial paper and lease balances. Cash is the reported cash and cash equivalents balance; it excludes other investment assets.

CFO already contains operating working-capital and noncash adjustments. Subtracting working capital or adding D&A again would double count. Full CapEx is used because maintenance CapEx cannot be isolated automatically. Stock compensation remains in the cash proxy through its CFO addback; it is separately disclosed. Purchases of intangibles, acquisitions and custom capital tags may be absent, so this proxy need not equal distributable cash.

Valuation requires five complete proxy years and positive average cash and shares. Normalize as the arithmetic mean of those five amounts. For years t=1 through 10, `cash[t] = mean_cash * (1 + growth)^t`; `PV[t] = cash[t] / (1 + discount)^t`. Terminal value is `cash[10] * terminal_multiple`, discounted ten years. Divide total present value by the latest annual weighted-average diluted shares. Lower/higher cases shift growth by minus/plus two percentage points; the other assumptions are fixed. These cases are sensitivities. This illustrative equity cash-flow model makes no debt or excess-cash adjustment and holds shares constant. Financial-sector SIC 6000–6999 disables valuation.

`margin_of_safety = (value - supplied_price) / value`. Without a positive dated user-supplied price, it stays null. `safety_threshold = value * (1 - safety_discount)` is computed independently. A price is an input, not a claim about the current market. Neither computed field is a trade recommendation.

Five years can be too short for cyclical normalization. Review leases, dilution, required reinvestment, financing changes and the narrative before drawing conclusions. A cash-flow model does not establish a moat or management integrity.
