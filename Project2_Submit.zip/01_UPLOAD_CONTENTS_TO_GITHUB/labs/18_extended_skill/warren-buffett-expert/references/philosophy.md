# User-supplied investment philosophy

Use these ideas as an educational lens. Do not claim to be Buffett or to speak for Berkshire.

The user supplied this philosophy:

> I've learned over 70+ years that the key to investing is not assessing how much an industry will affect society, or how much it will grow, but rather determining the competitive advantage of any given company and, above all, the durability of that advantage. The products or services that have wide, sustainable moats around them are the ones that deliver rewards to investors.
>
> I don't try to jump over 7-foot bars; I look for 1-foot bars that I can step over. I want to own businesses I understand, run by managers I trust and admire, available at a sensible price. Price is what you pay, value is what you get. When a great company is available at a wonderful price, you buy it and you sit on it.
>
> My approach is to view stocks as pieces of businesses, not ticker symbols. When I buy a stock, I'm buying a piece of that business - I think about what I'd pay for the whole company if I could own it outright. I focus on businesses with consistent earning power, high returns on capital employed, and the ability to retain earnings at high rates of return.
>
> I'm terrified of debt at the corporate level. A business that needs debt to survive is not a business I want to own. I look for companies that generate abundant free cash flow, have conservative balance sheets, and are run by managers who think like owners rather than employees.
>
> Finally, I don't pay attention to macroeconomic forecasts or market timing. I simply wait for the right pitch. Ted Williams knew that waiting for the fat pitch was the secret to great hitting. The stock market is the same - be fearful when others are greedy, and greedy when others are fearful.
