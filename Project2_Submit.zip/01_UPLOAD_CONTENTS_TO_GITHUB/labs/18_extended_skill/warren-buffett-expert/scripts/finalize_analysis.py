"""Populate the user's exact analysis structure from computed financial evidence."""
import argparse
import copy
import json
from pathlib import Path

from buffett import DISCLAIMER, save_json, sha

MISSING = "Data not available"


def check_keys(value, schema, path="root"):
    if isinstance(schema, dict):
        if not isinstance(value, dict) or set(value) != set(schema):
            raise ValueError(f"Unexpected or missing keys in {path}")
        for key in schema:
            check_keys(value[key], schema[key], path + "." + key)
    elif isinstance(schema, list):
        if not isinstance(value, list) or not value:
            raise ValueError(f"Nonempty array required at {path}")


def no_missing_fields(value):
    if isinstance(value, dict):
        return all(no_missing_fields(x) for x in value.values())
    if isinstance(value, list):
        return bool(value) and all(no_missing_fields(x) for x in value)
    return value is not None and value != ""


def finalize(evidence, judgment):
    schema = json.loads((Path(__file__).resolve().parents[1] / "references/output_schema.json").read_text(encoding="utf-8"))
    check_keys(judgment, schema)
    result = copy.deepcopy(judgment)
    if result["expert"] != "warren_buffett" or result["signal"] not in {"bullish", "neutral", "bearish"}:
        raise ValueError("Invalid expert or signal")
    if type(result["confidence"]) is not int or not 0 <= result["confidence"] <= 100:
        raise ValueError("Confidence must be a subjective integer from zero to one hundred")
    for section in ("circle_of_competence", "moat_analysis", "management_quality"):
        score = result["analysis"][section]["score"]
        if score != MISSING and (type(score) not in (int, float) or not 0 <= score <= 10):
            raise ValueError(f"Invalid judgment score: {section}")
        result["analysis"][section]["max_score"] = 10
    latest = evidence["annual"][0]
    facts, metrics = latest["facts"], latest["metrics"]
    summary = evidence["cash_history_summary"]
    def bn(value):
        return f"${value / 1e9:,.3f} billion" if value is not None else MISSING
    def per_share(value):
        return f"${value:,.3f}" if value is not None else MISSING
    financial_summary = f"For the year ended {latest['period_end']}, operating cash flow was {bn(facts['operating_cash_flow']['value'])}, property-and-equipment spending was {bn(facts['capital_spending']['value'])}, and the cash proxy was {bn(metrics['owner_cash_proxy'])}."
    proxy_summary = f"The script's CFO-minus-total-CapEx proxy is {per_share(metrics['owner_cash_per_diluted_share'])} per diluted share for {latest['period_end']}; its five-year average annual per-share proxy is {per_share(summary['mean_owner_cash_per_diluted_share'])}. The five-year average cash amount is {bn(summary['mean_owner_cash_proxy'])}, with {summary['negative_proxy_years']} negative annual observations."
    result["thesis"] = result["thesis"].replace("{financial_summary}", financial_summary)
    oe = result["analysis"]["owner_earnings"]
    oe["reported_eps"] = facts["reported_eps"]["value"] if facts["reported_eps"]["value"] is not None else MISSING
    oe["owner_earnings_per_share"] = evidence["owner_earnings"]["per_share"] if evidence["owner_earnings"]["available"] else MISSING
    oe["5yr_average_owner_eps"] = evidence["owner_earnings"]["five_year_average_per_share"] if evidence["owner_earnings"]["available"] else MISSING
    oe["reasoning"] = oe["reasoning"].replace("{cash_proxy_summary}", proxy_summary)
    value = evidence["valuation"]
    iv = result["analysis"]["intrinsic_value"]
    mos = result["analysis"]["margin_of_safety"]
    price = evidence["assumptions"]["price"]
    mos["current_price"] = price if price is not None else MISSING
    if value["available"]:
        low, base, high = value["scenarios"]
        iv.update(low_estimate=low["value_per_diluted_share"], base_estimate=base["value_per_diluted_share"], high_estimate=high["value_per_diluted_share"])
        mos["margin_percent"] = f"{base['margin_of_safety'] * 100:.2f}%" if base["margin_of_safety"] is not None else MISSING
        mos["meets_standards"] = base["margin_of_safety"] is not None and base["margin_of_safety"] >= evidence["assumptions"]["safety_discount"]
        result["would_buy_at"] = f"{per_share(low['safety_threshold'])}; illustrative lower-case safety threshold"
        result["would_sell_at"] = f"{per_share(base['value_per_diluted_share'])}; base-case computed value, not a trading forecast"
        result["forward_outlook"]["price_target"] = f"{per_share(low['value_per_diluted_share'])} to {per_share(high['value_per_diluted_share'])}; illustrative value sensitivity, not a dated price prediction"
    else:
        iv.update(low_estimate=MISSING, base_estimate=MISSING, high_estimate=MISSING)
        mos.update(margin_percent=MISSING, meets_standards=False)
        result["would_buy_at"] = result["would_sell_at"] = MISSING
        result["forward_outlook"]["price_target"] = MISSING
    if DISCLAIMER not in result["private_assessment"]:
        result["private_assessment"] += "\n\n" + DISCLAIMER
    if not no_missing_fields(result):
        raise ValueError("All fields must be filled; use Data not available instead of null or empty strings")
    return result


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--evidence", required=True, type=Path)
    p.add_argument("--judgment", required=True, type=Path)
    p.add_argument("--output", required=True, type=Path)
    a = p.parse_args()
    raw_evidence = a.evidence.read_bytes()
    evidence = json.loads(raw_evidence)
    result = finalize(evidence, json.loads(a.judgment.read_text(encoding="utf-8")))
    save_json(a.output, result)
    save_json(a.output.with_suffix(".receipt.json"), {"evidence_sha256": sha(raw_evidence), "evidence_fingerprint": evidence["evidence_fingerprint"], "judgment_sha256": sha(a.judgment.read_bytes()), "analysis_sha256": sha(a.output.read_bytes()), "subjective_fields": ["signal", "confidence", "analysis.circle_of_competence.score", "analysis.moat_analysis.score", "analysis.management_quality.score", "analysis.management_quality.capital_allocation_grade"], "scope": "Annual 10-K review; not a complete current-events or all-filings update"})
    print(a.output.resolve())


if __name__ == "__main__":
    main()
