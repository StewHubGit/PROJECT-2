# Buffett as a skill

Built from the FAskills Buffett investor page and the supplied philosophy, criteria and exact JSON output structure. Intel is the initial worked review; Apple is a second SEC snapshot that demonstrates a complete positive-cash valuation path. The Lab 18 folder name is a local organizational choice, not a claim about an official course lab number.

Disclaimer: This tool is for educational and informational purposes only. It does not constitute financial advice, investment recommendations, or professional guidance of any kind. The analyses generated are AI-simulated perspectives and should not be used as the basis for any investment decisions. Always consult a qualified financial advisor before making investment decisions. Use at your own risk.

## Run the app

From the AIFinance2026 workspace:

```powershell
.\.venv\Scripts\python.exe -m streamlit run Lab18_Buffett_Skill/app.py --server.address 127.0.0.1 --server.port 8505 --server.headless true --server.showEmailPrompt false --browser.gatherUsageStats false
```

Open http://localhost:8505. The included Intel result loads immediately. Saved SEC snapshot mode makes no network requests. Use CIK `0000050863` for Intel and `0000320193` for Apple. Live mode refreshes sources, requires internet access and a real SEC request identity, and uses no API keys. SEC may block its ticker-directory or filing-HTML endpoints even while company APIs work; use a verified CIK, and preserve any failed-source notice. Never treat a cached result as a fresh download.

For another environment, install `requirements.txt` and replace the interpreter path with `python`. Python 3.14 and the pinned dependencies were used here.

## Run the same skill

The self-contained skill is [warren-buffett-expert/SKILL.md](warren-buffett-expert/SKILL.md). In Codex or Antigravity, ask:

> Read Lab18_Buffett_Skill/warren-buffett-expert/SKILL.md and run it on INTC using filings available by 2026-11-03. Use the saved SEC snapshot, verify the cited Intel filing, and return the required JSON.

If the skill is installed in the assistant's skill directory, invoke `$warren-buffett-expert` with the company and cutoff. Installation is separate from the portable project package.

Replay the Intel calculations:

```powershell
.\.venv\Scripts\python.exe Lab18_Buffett_Skill/warren-buffett-expert/scripts/buffett.py 0000050863 --asof 2026-11-03 --offline --output Lab18_Buffett_Skill/outputs/INTC
```

For live data omit `--offline`, supply `--user-agent` or set `SEC_USER_AGENT` to your real requester identity, and use `--refresh` to replace cached sources. Existing snapshots have original retrieval timestamps and SHA-256 receipts. Output folders are explicit and can be changed to preserve separate runs.

The script writes `evidence.json` and `judge_packet.md`. The assistant reads them and the selected filing, writes `judgment.json`, and runs:

```powershell
.\.venv\Scripts\python.exe Lab18_Buffett_Skill/warren-buffett-expert/scripts/finalize_analysis.py --evidence Lab18_Buffett_Skill/outputs/INTC/evidence.json --judgment Lab18_Buffett_Skill/outputs/INTC/judgment.json --output Lab18_Buffett_Skill/outputs/INTC/analysis.json
```

The finalizer checks the requested keys, inserts financial values from code, and writes a checksum receipt tying the model judgment to its evidence. The app only offers the completed review when the evidence fingerprint matches. It does not call a model API or pretend to generate fresh model judgments.

## What computes and what judges

Python selects original 10-K accessions by filing cutoff, exact fiscal end, unit and annual duration. It computes ratios, the CFO-minus-total-CapEx proxy, per-share amounts, historical means and conditional valuation sensitivities. Missing values remain missing. It does not invent maintenance CapEx, working-capital requirements or a recovery forecast.

The model assesses business understanding, moat, management, risks, catalysts and disconfirming evidence. Requested scores and confidence are subjective judgments, explicitly distinguished from computed financial values. The [source profile](warren-buffett-expert/references/source_profile.json) preserves the requested data requirements. Insider trades, news and Berkshire holdings are unassessed; no 13-F data was supplied. A dated price is optional and user-supplied. The annual review is not a current all-filings update.

The owner's requested full owner-earnings formula is preserved separately from the cash proxy. True owner earnings and its average remain unavailable without supported maintenance and working-capital inputs. Intel's proxy does not support the positive normalized-cash valuation used by this demonstration, so its intrinsic value, price targets and margin are `Data not available`. That does not establish a zero equity value. Apple illustrates how the same valuation code behaves with positive normalized cash. The default growth, discount, terminal and safety settings are assumptions; the default discount is not a live Treasury-plus-premium calculation.

## Evidence and verification

- [Intel exact-structure analysis](outputs/INTC/analysis.json), [computed evidence](outputs/INTC/evidence.json), [model input packet](outputs/INTC/judge_packet.md), and [receipt](outputs/INTC/analysis.receipt.json).
- [Raw SEC snapshots and receipts](evidence/downloads), [Intel inline-filing cross-check](evidence/0000050863_filing_crosscheck.json), and [extracted filing text](evidence/0000050863_filing_text.txt).
- The Intel HTML was already saved in `Project1_Intel/evidence`, with original retrieval date 2026-10-19. Its original manifest checksum was verified before use; this is disclosed in the cross-check. It is not a fresh HTML retrieval.
- [Method and source attribution](warren-buffett-expert/references/method.md), [judgment framework](warren-buffett-expert/references/framework.md), and [output structure](warren-buffett-expert/references/output_schema.json).

Run the automated checks:

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s Lab18_Buffett_Skill/tests -v
```

Verify Intel against the saved original HTML and manifest:

```powershell
.\.venv\Scripts\python.exe Lab18_Buffett_Skill/verify_filing.py --report Lab18_Buffett_Skill/outputs/INTC/evidence.json --local-filing Project1_Intel/evidence/intel_2025_10k.html --manifest Project1_Intel/evidence/manifest.json
```

The automated checks cover annual-versus-quarter selection, later-filing exclusion, conflicting contexts, missing inputs, cache integrity, offline replay, discounting against a closed-form answer and Streamlit recomputation/error behavior. The filing check independently compares the latest-year API facts to the filing's inline XBRL. Standard-tag coverage remains incomplete: Intel's unprovided liability totals and some earlier debt components are left missing, not derived by ignoring noncontrolling interests.
