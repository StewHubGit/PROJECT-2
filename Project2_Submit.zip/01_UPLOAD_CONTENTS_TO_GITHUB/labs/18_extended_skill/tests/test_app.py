from pathlib import Path
import unittest
from streamlit.testing.v1 import AppTest

APP = Path(__file__).resolve().parents[1] / "app.py"


class AppTests(unittest.TestCase):
    def test_saved_evidence_compute_and_changed_assumption(self):
        app = AppTest.from_file(str(APP)).run(timeout=30)
        self.assertFalse(app.exception)
        self.assertEqual(app.subheader[0].value, "INTEL CORP")
        self.assertIn("educational and informational", app.info[0].value)
        self.assertFalse(app.session_state["report"]["valuation"]["available"])
        app.text_input[0].set_value("0000320193")
        app.button[0].click().run(timeout=30)
        before = app.session_state["report"]["valuation"]["scenarios"][1]["value_per_diluted_share"]
        growth = next(x for x in app.number_input if x.label == "Annual cash growth (%)")
        growth.set_value(5.0)
        app.button[0].click().run(timeout=30)
        self.assertFalse(app.exception)
        self.assertFalse(app.error)
        self.assertGreater(app.session_state["report"]["valuation"]["scenarios"][1]["value_per_diluted_share"], before)
        self.assertEqual(app.session_state["report_mode"], "Saved SEC snapshot")

    def test_missing_offline_company_clears_previous_result(self):
        app = AppTest.from_file(str(APP)).run(timeout=30)
        app.text_input[0].set_value("0000000001")
        app.button[0].click().run(timeout=30)
        self.assertFalse(app.exception)
        self.assertTrue(app.error)
        self.assertNotIn("report", app.session_state)


if __name__ == "__main__":
    unittest.main()
