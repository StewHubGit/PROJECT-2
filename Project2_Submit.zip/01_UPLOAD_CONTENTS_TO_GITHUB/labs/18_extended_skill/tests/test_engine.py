import copy
from datetime import date
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "warren-buffett-expert" / "scripts"))
from buffett import EdgarClient, EdgarError, annual_filings, annual_rows, build_report, pick_fact, ratio, sha, valuation
from finalize_analysis import finalize, no_missing_fields

ASSUMPTIONS = {"growth_rate": 0.03, "discount_rate": 0.10, "terminal_multiple": 12, "safety_discount": 0.25, "price": None, "price_date": None}
FILING = {"reportDate": "2025-12-31", "filingDate": "2026-02-01", "accessionNumber": "A", "primaryDocument": "annual.htm", "form": "10-K"}


def fact(value=100, **overrides):
    return {"start": "2025-01-01", "end": "2025-12-31", "accn": "A", "form": "10-K", "filed": "2026-02-01", "val": value, **overrides}


def facts_for(metric, entries, unit="USD"):
    from buffett import TAGS
    return {"facts": {"us-gaap": {TAGS[metric][0]: {"units": {unit: entries}}}}}


class SelectionTests(unittest.TestCase):
    def test_quarter_later_filing_wrong_unit_and_period_are_excluded(self):
        facts = facts_for("revenue", [fact(100), fact(999, start="2025-10-01"), fact(999, accn="B"), fact(999, end="2024-12-31"), fact(999, form="10-Q"), fact(999, filed="2027-01-01")])
        self.assertEqual(pick_fact(facts, "revenue", FILING)["value"], 100)
        self.assertIsNone(pick_fact(facts_for("revenue", [fact()], "EUR"), "revenue", FILING)["value"])

    def test_duplicate_contexts_deduplicate_but_conflicts_are_missing(self):
        self.assertEqual(pick_fact(facts_for("revenue", [fact(), fact()]), "revenue", FILING)["value"], 100)
        self.assertIsNone(pick_fact(facts_for("revenue", [fact(), fact(200)]), "revenue", FILING)["value"])

    def test_missing_is_not_zero(self):
        self.assertIsNone(pick_fact({}, "capital_spending", FILING)["value"])
        self.assertEqual(pick_fact(facts_for("capital_spending", [fact(0)]), "capital_spending", FILING)["value"], 0)
        self.assertIsNone(pick_fact(facts_for("capital_spending", [fact(-1)]), "capital_spending", FILING)["value"])
        self.assertIsNone(ratio(3, 0))
        self.assertIsNone(ratio(3, -1))

    def test_filing_cutoff_original_and_amendment_exclusion(self):
        rows = [FILING, {**FILING, "form": "10-K/A", "accessionNumber": "AMEND"}, {**FILING, "filingDate": "2026-02-02", "accessionNumber": "LATER"}]
        table = {k: [r[k] for r in rows] for k in FILING}
        sub = {"filings": {"recent": table}}
        self.assertEqual(annual_filings(None, sub, "2026-02-01", 5)[0]["accessionNumber"], "A")
        with self.assertRaises(EdgarError):
            annual_filings(None, sub, "2026-01-31", 5)

    def test_older_submissions_page_is_used_when_needed(self):
        class Client:
            def get(self, url):
                return {k: [v] for k, v in FILING.items()}
        sub = {"filings": {"recent": {}, "files": [{"name": "CIK0000000001-submissions-001.json", "filingFrom": "2026-02-01", "filingTo": "2026-02-01"}]}}
        self.assertEqual(annual_filings(Client(), sub, "2026-02-01", 5)[0]["accessionNumber"], "A")


class ValuationTests(unittest.TestCase):
    def setUp(self):
        self.rows = [{"metrics": {"owner_cash_proxy": 100}, "facts": {"diluted_shares": {"value": 10}}} for _ in range(5)]

    def test_discounting_against_closed_form_annuity(self):
        a = {**ASSUMPTIONS, "growth_rate": 0, "terminal_multiple": 10, "price": 80, "price_date": "2026-01-01"}
        result = valuation(self.rows, a)["scenarios"][1]
        # Flat cash and terminal value: an independently written annuity expression.
        expected = (100 * (1 - 1.1 ** -10) / 0.1 + 1000 * 1.1 ** -10) / 10
        self.assertAlmostEqual(result["value_per_diluted_share"], expected)
        self.assertAlmostEqual(result["margin_of_safety"], (expected - 80) / expected)
        self.assertAlmostEqual(result["safety_threshold"], expected * 0.75)

    def test_no_price_no_margin_and_missing_history_blocks_value(self):
        self.assertIsNone(valuation(self.rows, ASSUMPTIONS)["scenarios"][1]["margin_of_safety"])
        self.rows[2]["metrics"]["owner_cash_proxy"] = None
        self.assertFalse(valuation(self.rows, ASSUMPTIONS)["available"])
        self.assertFalse(valuation(self.rows[:4], ASSUMPTIONS)["available"])

    def test_invalid_assumptions(self):
        for changes in ({"discount_rate": 0}, {"growth_rate": float("nan")}, {"price": 100}, {"price": -1, "price_date": "2025-01-01"}, {"safety_discount": 1}):
            with self.subTest(changes=changes), self.assertRaises(EdgarError):
                valuation(self.rows, {**ASSUMPTIONS, **changes})


class SnapshotTests(unittest.TestCase):
    def test_intel_final_output_uses_code_values_and_exact_schema(self):
        evidence = json.loads((ROOT / "outputs/INTC/evidence.json").read_text(encoding="utf-8"))
        judgment = json.loads((ROOT / "outputs/INTC/judgment.json").read_text(encoding="utf-8"))
        judgment["analysis"]["owner_earnings"]["reported_eps"] = 999
        judgment["analysis"]["intrinsic_value"]["base_estimate"] = 999
        result = finalize(evidence, judgment)
        self.assertEqual(result["analysis"]["owner_earnings"]["reported_eps"], -0.06)
        self.assertEqual(result["analysis"]["intrinsic_value"]["base_estimate"], "Data not available")
        self.assertNotIn("{financial_summary}", result["thesis"])
        self.assertFalse(result["analysis"]["margin_of_safety"]["meets_standards"])
        self.assertTrue(no_missing_fields(result))
        self.assertIn(evidence["disclaimer"], result["private_assessment"])
        judgment["invented_extra_key"] = "extra"
        with self.assertRaises(ValueError):
            finalize(evidence, judgment)

    def test_intel_filing_crosscheck_and_negative_history_gate(self):
        report = build_report(EdgarClient(ROOT / "evidence/downloads", "", offline=True), "0000050863", "2026-11-03", ASSUMPTIONS)
        crosscheck = json.loads((ROOT / "evidence/0000050863_filing_crosscheck.json").read_text(encoding="utf-8"))
        self.assertEqual(len(crosscheck["checks"]), 13)
        self.assertTrue(all(x["matches"] for x in crosscheck["checks"]))
        self.assertEqual(report["cash_history_summary"]["negative_proxy_years"], 4)
        self.assertFalse(report["valuation"]["available"])
        self.assertFalse(report["owner_earnings"]["available"])

    def test_integrity_failure_and_offline_never_fetches(self):
        with tempfile.TemporaryDirectory() as folder:
            client = EdgarClient(Path(folder), "", offline=True)
            with patch("requests.get", side_effect=AssertionError("Network must not be used")):
                with self.assertRaises(EdgarError):
                    client.get("https://data.sec.gov/submissions/CIK0000320193.json")

    def test_included_apple_snapshot_and_balance_identity(self):
        with patch("requests.get", side_effect=AssertionError("Replay contacted network")):
            client = EdgarClient(ROOT / "evidence" / "downloads", "", offline=True)
            report = build_report(client, "0000320193", "2026-11-03", ASSUMPTIONS)
        self.assertEqual(len(report["annual"]), 5)
        self.assertEqual(report["missing_facts"], [])
        for row in report["annual"]:
            raw = row["facts"]
            self.assertEqual(raw["assets"]["value"], raw["liabilities"]["value"] + raw["equity"]["value"])
            self.assertTrue(all(x["accession"] == row["accession"] for x in raw.values()))
        # Known-answer values from the filed FY2024 statements, not application constants.
        fy24 = next(r for r in report["annual"] if r["period_end"] == "2024-09-28")
        self.assertEqual(fy24["facts"]["operating_cash_flow"]["value"], 118254000000)
        self.assertEqual(fy24["facts"]["capital_spending"]["value"], 9447000000)
        self.assertEqual(fy24["metrics"]["owner_cash_proxy"], 108807000000)
        old = build_report(EdgarClient(ROOT / "evidence" / "downloads", "", offline=True), "0000320193", "2026-11-02", ASSUMPTIONS)
        self.assertLess(old["annual"][0]["filed"], "2026-11-03")
        self.assertEqual(old["annual"][0]["period_end"], "2025-09-27")

    def test_tampered_cached_bytes_are_rejected(self):
        with tempfile.TemporaryDirectory() as folder:
            url = "https://data.sec.gov/submissions/CIK0000000001.json"
            key = sha(url.encode())
            Path(folder, key + ".json").write_bytes(b"{}")
            Path(folder, key + ".receipt.json").write_text(json.dumps({"url": url, "sha256": "incorrect"}))
            with self.assertRaises(EdgarError):
                EdgarClient(Path(folder), "", offline=True).get(url)


if __name__ == "__main__":
    unittest.main()
