"""Run from the workspace: python -m streamlit run Lab18_Buffett_Skill/app.py"""
from datetime import date
import json
import os
from pathlib import Path
import sys

import pandas as pd
import streamlit as st

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / "warren-buffett-expert" / "scripts"))
from buffett import DISCLAIMER, EdgarClient, EdgarError, build_report, judgment_packet

st.set_page_config(page_title="Buffett as a skill", page_icon="📖", layout="wide")
st.title("Buffett as a skill")
st.caption("SEC filings → Python calculations → evidence → model judgment")
st.info(DISCLAIMER)
st.write("Explore five annual filings with the same calculations every time. Python computes the financial evidence; your AI assistant assesses the business and the limits of that evidence.")

with st.sidebar:
    st.header("Run the workflow")
    with st.form("inputs"):
        company = st.text_input("US ticker or CIK", "0000050863", help="Intel CIK is prefilled. Apple is 0000320193. Use a CIK if the SEC ticker directory is blocked.")
        cutoff = st.date_input("Filings available by", date.today(), max_value=date.today())
        mode = st.selectbox("Data mode", ["Saved SEC snapshot", "Live SEC download"])
        user_agent = st.text_input("SEC request identity", os.getenv("SEC_USER_AGENT", ""), help="For live requests enter your real name, organization and contact information. No API key is needed.")
        st.caption("Valuation assumptions — these are not filing facts.")
        growth = st.number_input("Annual cash growth (%)", -45.0, 45.0, 3.0, 0.5)
        discount = st.number_input("Discount rate (%)", 0.5, 100.0, 10.0, 0.5)
        multiple = st.number_input("Terminal cash multiple", 1.0, 30.0, 12.0, 0.5)
        safety = st.number_input("Safety discount (%)", 0.0, 95.0, 25.0, 5.0)
        use_price = st.checkbox("Include a dated user-supplied share price")
        price = st.number_input("Share price (USD)", min_value=0.01, value=100.0, disabled=not use_price)
        price_date = st.date_input("Price observed on", date.today(), max_value=date.today(), disabled=not use_price)
        run = st.form_submit_button("Compute evidence", type="primary")
    st.caption("Saved snapshots make no network requests. Live runs refresh each source. A failed download is never replaced silently.")

if run:
    st.session_state.pop("report", None)
    try:
        with st.spinner("Selecting filings and computing evidence…"):
            client = EdgarClient(HERE / "evidence" / "downloads", user_agent, offline=mode == "Saved SEC snapshot", refresh=mode == "Live SEC download")
            assumptions = {"growth_rate": growth / 100, "discount_rate": discount / 100, "terminal_multiple": multiple, "safety_discount": safety / 100, "price": price if use_price else None, "price_date": price_date.isoformat() if use_price else None}
            st.session_state.report = build_report(client, company, cutoff.isoformat(), assumptions)
            st.session_state.report_mode = mode
    except (EdgarError, ValueError, KeyError, OSError) as exc:
        st.error(str(exc))

if "report" not in st.session_state:
    sample = HERE / "outputs" / "INTC" / "evidence.json"
    if sample.exists() and not run:
        st.session_state.report = json.loads(sample.read_text(encoding="utf-8"))
        st.session_state.report_mode = "Included Intel demonstration — saved SEC evidence"
    else:
        st.write("Choose a company and compute evidence to begin.")
        st.stop()

if "report" not in st.session_state:
    st.stop()
report = st.session_state.report
st.subheader(report["company"])
st.caption(f"{st.session_state.report_mode} · filing cutoff {report['filing_cutoff']} · built {report['built_at_utc']}")
st.caption("The displayed result changes after you select Compute evidence. Downloads preserve the assumptions used for this result.")
annual = report["annual"]
st.link_button("Open latest selected 10-K", annual[0]["filing_url"])
history, value_tab, evidence_tab, judgment_tab = st.tabs(["Cash and quality", "Valuation sensitivity", "Filing evidence", "Model judgment"])

with history:
    st.write("Owner cash proxy = operating cash flow − total property, plant and equipment spending. Maintenance spending is not separately estimated.")
    frame = pd.DataFrame([{"Fiscal year end": row["period_end"], "Revenue ($m)": row["facts"]["revenue"]["value"] / 1e6 if row["facts"]["revenue"]["value"] is not None else None, "Operating cash flow ($m)": row["facts"]["operating_cash_flow"]["value"] / 1e6 if row["facts"]["operating_cash_flow"]["value"] is not None else None, "Capital spending ($m)": row["facts"]["capital_spending"]["value"] / 1e6 if row["facts"]["capital_spending"]["value"] is not None else None, "Owner cash proxy ($m)": row["metrics"]["owner_cash_proxy"] / 1e6 if row["metrics"]["owner_cash_proxy"] is not None else None, "Owner cash / diluted share ($)": row["metrics"]["owner_cash_per_diluted_share"], "Net margin (%)": row["metrics"]["net_margin"] * 100 if row["metrics"]["net_margin"] is not None else None, "ROE on average equity (%)": row["metrics"]["return_on_average_equity"] * 100 if row["metrics"]["return_on_average_equity"] is not None else None, "Liabilities / assets (%)": row["metrics"]["liabilities_to_assets"] * 100 if row["metrics"]["liabilities_to_assets"] is not None else None} for row in annual])
    st.line_chart(frame.set_index("Fiscal year end")[["Operating cash flow ($m)", "Capital spending ($m)", "Owner cash proxy ($m)"]].sort_index())
    st.dataframe(frame, hide_index=True, width="stretch", column_config={name: st.column_config.NumberColumn(format="%.2f") for name in frame.columns if name != "Fiscal year end"})
    st.caption("Blank means unavailable or undefined. ROE requires positive opening and closing equity from the same filing. Liabilities/assets includes non-debt liabilities; it is not a debt ratio.")

with value_tab:
    st.warning("This is a simplified operating-company cash-flow illustration. Cash flow is not the same as true owner earnings. Read the limitations before interpreting a value.")
    a = report["assumptions"]
    st.json(a, expanded=False)
    val = report["valuation"]
    if val["available"]:
        st.metric("Five-year mean owner cash proxy", f"${val['normalized_owner_cash'] / 1e9:,.2f}bn")
        st.write("Each case projects cash for ten years, discounts it, and adds a discounted terminal cash multiple. All cases use the latest annual weighted-average diluted shares, held constant.")
        table = pd.DataFrame([{"Case": row["scenario"], "Growth (%)": row["growth_rate"] * 100, "Illustrative value / share ($)": row["value_per_diluted_share"], "Value after safety discount ($)": row["safety_threshold"], "Margin of safety (%)": row["margin_of_safety"] * 100 if row["margin_of_safety"] is not None else None} for row in val["scenarios"]])
        st.dataframe(table, hide_index=True, width="stretch", column_config={name: st.column_config.NumberColumn(format="%.2f") for name in table.columns if name != "Case"})
        if a["price"] is None:
            st.caption("No share price was supplied. Margin of safety remains blank. The placeholder price in the sidebar is unused until its checkbox is selected.")
        with st.expander("Cash projection and discounting schedule"):
            for row in val["scenarios"]:
                st.write(row["scenario"])
                st.dataframe(row["schedule"], hide_index=True)
    else:
        st.info(val["reason"])

with evidence_tab:
    st.write(report["selection_policy"])
    st.write("Requested source profile and available data")
    st.dataframe([{"Input": name, "Coverage": status} for name, status in report["data_coverage"].items()], hide_index=True, width="stretch")
    for row in annual:
        with st.expander(f"{row['period_end']} · filed {row['filed']} · {row['accession']}"):
            st.markdown(f"[Read original filing]({row['filing_url']})")
            st.dataframe(pd.DataFrame([{"metric": name, **fact} for name, fact in row["facts"].items()]), hide_index=True, width="stretch")
            st.json({"opening_equity": row["opening_equity"], "metrics": row["metrics"]}, expanded=False)
    st.write("Download receipts and checksums")
    st.dataframe(report["receipts"], hide_index=True)
    if report["missing_facts"]:
        st.warning("Some filing facts are unavailable.")
        st.dataframe(report["missing_facts"], hide_index=True)
    st.download_button("Download computed evidence (JSON)", json.dumps(report, indent=2), file_name=f"buffett_{report['cik']}_{report['filing_cutoff']}.json", mime="application/json")

with judgment_tab:
    st.write("Download this packet and give it to Codex or Antigravity with the included SKILL.md. The assistant should read the cited filing sections and return qualitative judgments with evidence references. No model API key is required by this app.")
    st.write("The review covers business understanding, competitive advantage, management, cash earning quality, valuation assumptions and margin of safety. Missing evidence stays unassessed.")
    packet = judgment_packet(report)
    st.download_button("Download model judgment packet", packet, file_name="judge_packet.md", mime="text/markdown")
    with st.expander("Preview model instructions and evidence"):
        st.code(packet, language="markdown")
    st.caption("The app generates the packet; it does not claim to have completed an AI review.")
    saved_folder = HERE / "outputs" / "INTC"
    saved_analysis = saved_folder / "analysis.json"
    saved_receipt = saved_folder / "analysis.receipt.json"
    if saved_analysis.exists() and saved_receipt.exists():
        receipt = json.loads(saved_receipt.read_text(encoding="utf-8"))
        if receipt["evidence_fingerprint"] == report["evidence_fingerprint"]:
            st.subheader("Completed Intel model judgment")
            st.caption("Scores, signal and confidence are subjective model judgments. Financial fields were populated by the script. This review matches the displayed evidence and assumptions.")
            analysis_text = saved_analysis.read_text(encoding="utf-8")
            st.json(json.loads(analysis_text), expanded=False)
            st.download_button("Download completed Intel analysis", analysis_text, file_name="INTC_analysis.json", mime="application/json")
        elif report["cik"] == "0000050863":
            st.info("The saved Intel judgment uses different evidence or assumptions. Generate a new judgment for this run.")

with st.expander("Method and limitations", expanded=False):
    for item in report["limitations"]:
        st.write("• " + item)
    st.markdown(f"[FAskills Buffett framework]({report['framework_source']}) · [SEC public API documentation](https://www.sec.gov/search-filings/edgar-application-programming-interfaces)")
