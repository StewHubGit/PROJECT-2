# JPM | JPMORGAN CHASE & CO
Filing cutoff: 2026-11-05
USD millions unless a ratio or percentage is labeled. Calculations use unrounded USD facts.
ROE = net income / fiscal-year-end equity; owner earnings proxy = operating cash flow - capital spending.
Current ratio = current assets / current liabilities; liabilities/equity uses total liabilities, not debt.

| FY end | Revenue | Net income | OCF | Capex | Equity | Current assets | Current liabilities | Liabilities | ROE | Owner earnings | Current ratio | Liabilities/equity | OCF minus NI |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 2021-12-31 | 121,649 | 48,334 | 78,084 | not found | 294,127 | not found | not found | 3,449,440 | 16.4% | not found | not known | 11.73 | 29,750 |
| 2022-12-31 | 128,695 | 37,676 | 107,119 | not found | 292,332 | not found | not found | 3,373,411 | 12.9% | not found | not known | 11.54 | 69,443 |
| 2023-12-31 | 158,104 | 49,552 | 12,974 | not found | 327,878 | not found | not found | 3,547,515 | 15.1% | not found | not known | 10.82 | -36,578 |
| 2024-12-31 | 177,556 | 58,471 | -42,012 | not found | 344,758 | not found | not found | 3,658,056 | 17.0% | not found | not known | 10.61 | -100,483 |
| 2025-12-31 | 182,447 | 57,048 | -147,782 | not found | 362,438 | not found | not found | 4,062,462 | 15.7% | not found | not known | 11.21 | -204,830 |

| Investor | Check | Result |
|---|---|---|
| Buffett | ROE of 15% or more every year | fail |
| Buffett | Owner earnings positive every year | not known |
| Buffett | Owner earnings grew, first year to last | not known |
| Graham | Current ratio of 2.0 or more, latest year | not known |
| Graham | Net income positive every year | pass |
| Graham | Net income grew, first year to last | pass |
| Burry | Operating cash flow at least net income every year | fail |
| Burry | Liabilities no more than 2 times equity, latest year | fail |
Buffett: 0 of 3 passed; 1 failed; 2 not known. Verdict: not known.
Graham: 2 of 3 passed; 0 failed; 1 not known. Verdict: not known.
Burry: 0 of 2 passed; 2 failed; 0 not known. Verdict: fail.
Thresholds: ROE 15.0%; current ratio 2.0; liabilities/equity 2.0.
Interpretation: 5 annual observations required. A missing required input stays not found; its dependent check stays not known.
Valuation: current price not found; intrinsic value not known; margin of safety not known; price target not known.
Revenue-recognition fraud: not known; these eight checks cannot establish fraud.

## Source provenance
2021-12-31
- revenue: Revenues; filed 2024-02-16; accession 0000019617-24-000225; USD, exact fiscal period.
- net_income: NetIncomeLoss; filed 2024-02-16; accession 0000019617-24-000225; USD, exact fiscal period.
- operating_cash_flow: NetCashProvidedByUsedInOperatingActivities; filed 2024-02-16; accession 0000019617-24-000225; USD, exact fiscal period.
- capital_spending: not found; filed not found; accession not found; No eligible USD 10-K fact under the documented tags..
- equity: StockholdersEquity; filed 2024-02-16; accession 0000019617-24-000225; USD, exact fiscal period.
- liabilities: Liabilities; filed 2023-02-21; accession 0000019617-23-000231; USD, exact fiscal period.
- current_assets: not found; filed not found; accession not found; No eligible USD 10-K fact under the documented tags..
- current_liabilities: not found; filed not found; accession not found; No eligible USD 10-K fact under the documented tags..
2022-12-31
- revenue: Revenues; filed 2025-02-14; accession 0000019617-25-000270; USD, exact fiscal period.
- net_income: NetIncomeLoss; filed 2025-02-14; accession 0000019617-25-000270; USD, exact fiscal period.
- operating_cash_flow: NetCashProvidedByUsedInOperatingActivities; filed 2025-02-14; accession 0000019617-25-000270; USD, exact fiscal period.
- capital_spending: not found; filed not found; accession not found; No eligible USD 10-K fact under the documented tags..
- equity: StockholdersEquity; filed 2025-02-14; accession 0000019617-25-000270; USD, exact fiscal period.
- liabilities: Liabilities; filed 2024-02-16; accession 0000019617-24-000225; USD, exact fiscal period.
- current_assets: not found; filed not found; accession not found; No eligible USD 10-K fact under the documented tags..
- current_liabilities: not found; filed not found; accession not found; No eligible USD 10-K fact under the documented tags..
2023-12-31
- revenue: Revenues; filed 2026-02-13; accession 0001628280-26-008131; USD, exact fiscal period.
- net_income: NetIncomeLoss; filed 2026-02-13; accession 0001628280-26-008131; USD, exact fiscal period.
- operating_cash_flow: NetCashProvidedByUsedInOperatingActivities; filed 2026-02-13; accession 0001628280-26-008131; USD, exact fiscal period.
- capital_spending: not found; filed not found; accession not found; No eligible USD 10-K fact under the documented tags..
- equity: StockholdersEquity; filed 2026-02-13; accession 0001628280-26-008131; USD, exact fiscal period.
- liabilities: Liabilities; filed 2025-02-14; accession 0000019617-25-000270; USD, exact fiscal period.
- current_assets: not found; filed not found; accession not found; No eligible USD 10-K fact under the documented tags..
- current_liabilities: not found; filed not found; accession not found; No eligible USD 10-K fact under the documented tags..
2024-12-31
- revenue: Revenues; filed 2026-02-13; accession 0001628280-26-008131; USD, exact fiscal period.
- net_income: NetIncomeLoss; filed 2026-02-13; accession 0001628280-26-008131; USD, exact fiscal period.
- operating_cash_flow: NetCashProvidedByUsedInOperatingActivities; filed 2026-02-13; accession 0001628280-26-008131; USD, exact fiscal period.
- capital_spending: not found; filed not found; accession not found; No eligible USD 10-K fact under the documented tags..
- equity: StockholdersEquity; filed 2026-02-13; accession 0001628280-26-008131; USD, exact fiscal period.
- liabilities: Liabilities; filed 2026-02-13; accession 0001628280-26-008131; USD, exact fiscal period.
- current_assets: not found; filed not found; accession not found; No eligible USD 10-K fact under the documented tags..
- current_liabilities: not found; filed not found; accession not found; No eligible USD 10-K fact under the documented tags..
2025-12-31
- revenue: Revenues; filed 2026-02-13; accession 0001628280-26-008131; USD, exact fiscal period.
- net_income: NetIncomeLoss; filed 2026-02-13; accession 0001628280-26-008131; USD, exact fiscal period.
- operating_cash_flow: NetCashProvidedByUsedInOperatingActivities; filed 2026-02-13; accession 0001628280-26-008131; USD, exact fiscal period.
- capital_spending: not found; filed not found; accession not found; No eligible USD 10-K fact under the documented tags..
- equity: StockholdersEquity; filed 2026-02-13; accession 0001628280-26-008131; USD, exact fiscal period.
- liabilities: Liabilities; filed 2026-02-13; accession 0001628280-26-008131; USD, exact fiscal period.
- current_assets: not found; filed not found; accession not found; No eligible USD 10-K fact under the documented tags..
- current_liabilities: not found; filed not found; accession not found; No eligible USD 10-K fact under the documented tags..

## Missing-input register
- 2021-12-31 capital_spending: not found; No eligible USD 10-K fact under the documented tags.
- 2021-12-31 current_assets: not found; No eligible USD 10-K fact under the documented tags.
- 2021-12-31 current_liabilities: not found; No eligible USD 10-K fact under the documented tags.
- 2022-12-31 capital_spending: not found; No eligible USD 10-K fact under the documented tags.
- 2022-12-31 current_assets: not found; No eligible USD 10-K fact under the documented tags.
- 2022-12-31 current_liabilities: not found; No eligible USD 10-K fact under the documented tags.
- 2023-12-31 capital_spending: not found; No eligible USD 10-K fact under the documented tags.
- 2023-12-31 current_assets: not found; No eligible USD 10-K fact under the documented tags.
- 2023-12-31 current_liabilities: not found; No eligible USD 10-K fact under the documented tags.
- 2024-12-31 capital_spending: not found; No eligible USD 10-K fact under the documented tags.
- 2024-12-31 current_assets: not found; No eligible USD 10-K fact under the documented tags.
- 2024-12-31 current_liabilities: not found; No eligible USD 10-K fact under the documented tags.
- 2025-12-31 capital_spending: not found; No eligible USD 10-K fact under the documented tags.
- 2025-12-31 current_assets: not found; No eligible USD 10-K fact under the documented tags.
- 2025-12-31 current_liabilities: not found; No eligible USD 10-K fact under the documented tags.
