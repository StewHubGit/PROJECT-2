# NVDA | NVIDIA CORP
Filing cutoff: 2026-11-05
USD millions unless a ratio or percentage is labeled. Calculations use unrounded USD facts.
ROE = net income / fiscal-year-end equity; owner earnings proxy = operating cash flow - capital spending.
Current ratio = current assets / current liabilities; liabilities/equity uses total liabilities, not debt.

| FY end | Revenue | Net income | OCF | Capex | Equity | Current assets | Current liabilities | Liabilities | ROE | Owner earnings | Current ratio | Liabilities/equity | OCF minus NI |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 2022-01-30 | 26,914 | 9,752 | 9,108 | 976 | 26,612 | 28,829 | 4,335 | 17,575 | 36.6% | 8,132 | 6.65 | 0.66 | -644 |
| 2023-01-29 | 26,974 | 4,368 | 5,641 | 1,833 | 22,101 | 23,073 | 6,563 | 19,081 | 19.8% | 3,808 | 3.52 | 0.86 | 1,273 |
| 2024-01-28 | 60,922 | 29,760 | 28,090 | 1,069 | 42,978 | 44,345 | 10,631 | 22,750 | 69.2% | 27,021 | 4.17 | 0.53 | -1,670 |
| 2025-01-26 | 130,497 | 72,880 | 64,089 | 3,236 | 79,327 | 80,126 | 18,047 | 32,274 | 91.9% | 60,853 | 4.44 | 0.41 | -8,791 |
| 2026-01-25 | 215,938 | 120,067 | 102,718 | 6,042 | 157,293 | 125,605 | 32,163 | 49,510 | 76.3% | 96,676 | 3.91 | 0.31 | -17,349 |

| Investor | Check | Result |
|---|---|---|
| Buffett | ROE of 15% or more every year | pass |
| Buffett | Owner earnings positive every year | pass |
| Buffett | Owner earnings grew, first year to last | pass |
| Graham | Current ratio of 2.0 or more, latest year | pass |
| Graham | Net income positive every year | pass |
| Graham | Net income grew, first year to last | pass |
| Burry | Operating cash flow at least net income every year | fail |
| Burry | Liabilities no more than 2 times equity, latest year | pass |
Buffett: 3 of 3 passed; 0 failed; 0 not known. Verdict: pass.
Graham: 3 of 3 passed; 0 failed; 0 not known. Verdict: pass.
Burry: 1 of 2 passed; 1 failed; 0 not known. Verdict: fail.
Thresholds: ROE 15.0%; current ratio 2.0; liabilities/equity 2.0.
Interpretation: 5 annual observations required. A missing required input stays not found; its dependent check stays not known.
Valuation: current price not found; intrinsic value not known; margin of safety not known; price target not known.
Revenue-recognition fraud: not known; these eight checks cannot establish fraud.

## Source provenance
2022-01-30
- revenue: Revenues; filed 2024-02-21; accession 0001045810-24-000029; USD, exact fiscal period.
- net_income: NetIncomeLoss; filed 2024-02-21; accession 0001045810-24-000029; USD, exact fiscal period.
- operating_cash_flow: NetCashProvidedByUsedInOperatingActivities; filed 2024-02-21; accession 0001045810-24-000029; USD, exact fiscal period.
- capital_spending: PaymentsToAcquireProductiveAssets; filed 2024-02-21; accession 0001045810-24-000029; USD, exact fiscal period.
- equity: StockholdersEquity; filed 2025-02-26; accession 0001045810-25-000023; USD, exact fiscal period.
- liabilities: Liabilities; filed 2023-02-24; accession 0001045810-23-000017; USD, exact fiscal period.
- current_assets: AssetsCurrent; filed 2023-02-24; accession 0001045810-23-000017; USD, exact fiscal period.
- current_liabilities: LiabilitiesCurrent; filed 2023-02-24; accession 0001045810-23-000017; USD, exact fiscal period.
2023-01-29
- revenue: Revenues; filed 2025-02-26; accession 0001045810-25-000023; USD, exact fiscal period.
- net_income: NetIncomeLoss; filed 2025-02-26; accession 0001045810-25-000023; USD, exact fiscal period.
- operating_cash_flow: NetCashProvidedByUsedInOperatingActivities; filed 2025-02-26; accession 0001045810-25-000023; USD, exact fiscal period.
- capital_spending: PaymentsToAcquireProductiveAssets; filed 2025-02-26; accession 0001045810-25-000023; USD, exact fiscal period.
- equity: StockholdersEquity; filed 2026-02-25; accession 0001045810-26-000021; USD, exact fiscal period.
- liabilities: Liabilities; filed 2024-02-21; accession 0001045810-24-000029; USD, exact fiscal period.
- current_assets: AssetsCurrent; filed 2024-02-21; accession 0001045810-24-000029; USD, exact fiscal period.
- current_liabilities: LiabilitiesCurrent; filed 2024-02-21; accession 0001045810-24-000029; USD, exact fiscal period.
2024-01-28
- revenue: Revenues; filed 2026-02-25; accession 0001045810-26-000021; USD, exact fiscal period.
- net_income: NetIncomeLoss; filed 2026-02-25; accession 0001045810-26-000021; USD, exact fiscal period.
- operating_cash_flow: NetCashProvidedByUsedInOperatingActivities; filed 2026-02-25; accession 0001045810-26-000021; USD, exact fiscal period.
- capital_spending: PaymentsToAcquireProductiveAssets; filed 2026-02-25; accession 0001045810-26-000021; USD, exact fiscal period.
- equity: StockholdersEquity; filed 2026-02-25; accession 0001045810-26-000021; USD, exact fiscal period.
- liabilities: Liabilities; filed 2025-02-26; accession 0001045810-25-000023; USD, exact fiscal period.
- current_assets: AssetsCurrent; filed 2025-02-26; accession 0001045810-25-000023; USD, exact fiscal period.
- current_liabilities: LiabilitiesCurrent; filed 2025-02-26; accession 0001045810-25-000023; USD, exact fiscal period.
2025-01-26
- revenue: Revenues; filed 2026-02-25; accession 0001045810-26-000021; USD, exact fiscal period.
- net_income: NetIncomeLoss; filed 2026-02-25; accession 0001045810-26-000021; USD, exact fiscal period.
- operating_cash_flow: NetCashProvidedByUsedInOperatingActivities; filed 2026-02-25; accession 0001045810-26-000021; USD, exact fiscal period.
- capital_spending: PaymentsToAcquireProductiveAssets; filed 2026-02-25; accession 0001045810-26-000021; USD, exact fiscal period.
- equity: StockholdersEquity; filed 2026-02-25; accession 0001045810-26-000021; USD, exact fiscal period.
- liabilities: Liabilities; filed 2026-02-25; accession 0001045810-26-000021; USD, exact fiscal period.
- current_assets: AssetsCurrent; filed 2026-02-25; accession 0001045810-26-000021; USD, exact fiscal period.
- current_liabilities: LiabilitiesCurrent; filed 2026-02-25; accession 0001045810-26-000021; USD, exact fiscal period.
2026-01-25
- revenue: Revenues; filed 2026-02-25; accession 0001045810-26-000021; USD, exact fiscal period.
- net_income: NetIncomeLoss; filed 2026-02-25; accession 0001045810-26-000021; USD, exact fiscal period.
- operating_cash_flow: NetCashProvidedByUsedInOperatingActivities; filed 2026-02-25; accession 0001045810-26-000021; USD, exact fiscal period.
- capital_spending: PaymentsToAcquireProductiveAssets; filed 2026-02-25; accession 0001045810-26-000021; USD, exact fiscal period.
- equity: StockholdersEquity; filed 2026-02-25; accession 0001045810-26-000021; USD, exact fiscal period.
- liabilities: Liabilities; filed 2026-02-25; accession 0001045810-26-000021; USD, exact fiscal period.
- current_assets: AssetsCurrent; filed 2026-02-25; accession 0001045810-26-000021; USD, exact fiscal period.
- current_liabilities: LiabilitiesCurrent; filed 2026-02-25; accession 0001045810-26-000021; USD, exact fiscal period.

## Missing-input register
- No required raw-input gaps found in this extraction.
