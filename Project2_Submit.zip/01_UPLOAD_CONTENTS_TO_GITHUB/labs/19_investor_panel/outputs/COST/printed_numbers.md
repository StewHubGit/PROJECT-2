# COST | COSTCO WHOLESALE CORP /NEW
Filing cutoff: 2026-11-05
USD millions unless a ratio or percentage is labeled. Calculations use unrounded USD facts.
ROE = net income / fiscal-year-end equity; owner earnings proxy = operating cash flow - capital spending.
Current ratio = current assets / current liabilities; liabilities/equity uses total liabilities, not debt.

| FY end | Revenue | Net income | OCF | Capex | Equity | Current assets | Current liabilities | Liabilities | ROE | Owner earnings | Current ratio | Liabilities/equity | OCF minus NI |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 2022-08-28 | 226,954 | 5,844 | 7,392 | 3,891 | 20,642 | 32,696 | 31,998 | 43,519 | 28.3% | 3,501 | 1.02 | 2.11 | 1,548 |
| 2023-09-03 | 242,290 | 6,292 | 11,068 | 4,323 | 25,058 | 35,879 | 33,583 | 43,936 | 25.1% | 6,745 | 1.07 | 1.75 | 4,776 |
| 2024-09-01 | 254,453 | 7,367 | 11,339 | 4,710 | 23,622 | 34,246 | 35,464 | 46,209 | 31.2% | 6,629 | 0.97 | 1.96 | 3,972 |
| 2025-08-31 | 275,235 | 8,099 | 13,335 | 5,498 | 29,164 | 38,380 | 37,108 | 47,935 | 27.8% | 7,837 | 1.03 | 1.64 | 5,236 |
| 2026-08-30 | 303,154 | 9,226 | 15,817 | 6,435 | 35,803 | 46,582 | 43,952 | 53,242 | 25.8% | 9,382 | 1.06 | 1.49 | 6,591 |

| Investor | Check | Result |
|---|---|---|
| Buffett | ROE of 15% or more every year | pass |
| Buffett | Owner earnings positive every year | pass |
| Buffett | Owner earnings grew, first year to last | pass |
| Graham | Current ratio of 2.0 or more, latest year | fail |
| Graham | Net income positive every year | pass |
| Graham | Net income grew, first year to last | pass |
| Burry | Operating cash flow at least net income every year | pass |
| Burry | Liabilities no more than 2 times equity, latest year | pass |
Buffett: 3 of 3 passed; 0 failed; 0 not known. Verdict: pass.
Graham: 2 of 3 passed; 1 failed; 0 not known. Verdict: fail.
Burry: 2 of 2 passed; 0 failed; 0 not known. Verdict: pass.
Thresholds: ROE 15.0%; current ratio 2.0; liabilities/equity 2.0.
Interpretation: 5 annual observations required. A missing required input stays not found; its dependent check stays not known.
Valuation: current price not found; intrinsic value not known; margin of safety not known; price target not known.
Revenue-recognition fraud: not known; these eight checks cannot establish fraud.

## Source provenance
2022-08-28
- revenue: RevenueFromContractWithCustomerExcludingAssessedTax; filed 2024-10-09; accession 0000909832-24-000049; USD, exact fiscal period.
- net_income: NetIncomeLoss; filed 2024-10-09; accession 0000909832-24-000049; USD, exact fiscal period.
- operating_cash_flow: NetCashProvidedByUsedInOperatingActivities; filed 2024-10-09; accession 0000909832-24-000049; USD, exact fiscal period.
- capital_spending: PaymentsToAcquirePropertyPlantAndEquipment; filed 2024-10-09; accession 0000909832-24-000049; USD, exact fiscal period.
- equity: StockholdersEquity; filed 2023-10-11; accession 0000909832-23-000042; USD, exact fiscal period.
- liabilities: Liabilities; filed 2023-10-11; accession 0000909832-23-000042; USD, exact fiscal period.
- current_assets: AssetsCurrent; filed 2023-10-11; accession 0000909832-23-000042; USD, exact fiscal period.
- current_liabilities: LiabilitiesCurrent; filed 2023-10-11; accession 0000909832-23-000042; USD, exact fiscal period.
2023-09-03
- revenue: RevenueFromContractWithCustomerExcludingAssessedTax; filed 2025-10-08; accession 0000909832-25-000101; USD, exact fiscal period.
- net_income: NetIncomeLoss; filed 2025-10-08; accession 0000909832-25-000101; USD, exact fiscal period.
- operating_cash_flow: NetCashProvidedByUsedInOperatingActivities; filed 2025-10-08; accession 0000909832-25-000101; USD, exact fiscal period.
- capital_spending: PaymentsToAcquirePropertyPlantAndEquipment; filed 2025-10-08; accession 0000909832-25-000101; USD, exact fiscal period.
- equity: StockholdersEquity; filed 2026-10-07; accession 0000909832-26-000093; USD, exact fiscal period.
- liabilities: Liabilities; filed 2024-10-09; accession 0000909832-24-000049; USD, exact fiscal period.
- current_assets: AssetsCurrent; filed 2024-10-09; accession 0000909832-24-000049; USD, exact fiscal period.
- current_liabilities: LiabilitiesCurrent; filed 2024-10-09; accession 0000909832-24-000049; USD, exact fiscal period.
2024-09-01
- revenue: RevenueFromContractWithCustomerExcludingAssessedTax; filed 2026-10-07; accession 0000909832-26-000093; USD, exact fiscal period.
- net_income: NetIncomeLoss; filed 2026-10-07; accession 0000909832-26-000093; USD, exact fiscal period.
- operating_cash_flow: NetCashProvidedByUsedInOperatingActivities; filed 2026-10-07; accession 0000909832-26-000093; USD, exact fiscal period.
- capital_spending: PaymentsToAcquirePropertyPlantAndEquipment; filed 2026-10-07; accession 0000909832-26-000093; USD, exact fiscal period.
- equity: StockholdersEquity; filed 2026-10-07; accession 0000909832-26-000093; USD, exact fiscal period.
- liabilities: Liabilities; filed 2025-10-08; accession 0000909832-25-000101; USD, exact fiscal period.
- current_assets: AssetsCurrent; filed 2025-10-08; accession 0000909832-25-000101; USD, exact fiscal period.
- current_liabilities: LiabilitiesCurrent; filed 2025-10-08; accession 0000909832-25-000101; USD, exact fiscal period.
2025-08-31
- revenue: RevenueFromContractWithCustomerExcludingAssessedTax; filed 2026-10-07; accession 0000909832-26-000093; USD, exact fiscal period.
- net_income: NetIncomeLoss; filed 2026-10-07; accession 0000909832-26-000093; USD, exact fiscal period.
- operating_cash_flow: NetCashProvidedByUsedInOperatingActivities; filed 2026-10-07; accession 0000909832-26-000093; USD, exact fiscal period.
- capital_spending: PaymentsToAcquirePropertyPlantAndEquipment; filed 2026-10-07; accession 0000909832-26-000093; USD, exact fiscal period.
- equity: StockholdersEquity; filed 2026-10-07; accession 0000909832-26-000093; USD, exact fiscal period.
- liabilities: Liabilities; filed 2026-10-07; accession 0000909832-26-000093; USD, exact fiscal period.
- current_assets: AssetsCurrent; filed 2026-10-07; accession 0000909832-26-000093; USD, exact fiscal period.
- current_liabilities: LiabilitiesCurrent; filed 2026-10-07; accession 0000909832-26-000093; USD, exact fiscal period.
2026-08-30
- revenue: RevenueFromContractWithCustomerExcludingAssessedTax; filed 2026-10-07; accession 0000909832-26-000093; USD, exact fiscal period.
- net_income: NetIncomeLoss; filed 2026-10-07; accession 0000909832-26-000093; USD, exact fiscal period.
- operating_cash_flow: NetCashProvidedByUsedInOperatingActivities; filed 2026-10-07; accession 0000909832-26-000093; USD, exact fiscal period.
- capital_spending: PaymentsToAcquirePropertyPlantAndEquipment; filed 2026-10-07; accession 0000909832-26-000093; USD, exact fiscal period.
- equity: StockholdersEquity; filed 2026-10-07; accession 0000909832-26-000093; USD, exact fiscal period.
- liabilities: Liabilities; filed 2026-10-07; accession 0000909832-26-000093; USD, exact fiscal period.
- current_assets: AssetsCurrent; filed 2026-10-07; accession 0000909832-26-000093; USD, exact fiscal period.
- current_liabilities: LiabilitiesCurrent; filed 2026-10-07; accession 0000909832-26-000093; USD, exact fiscal period.

## Missing-input register
- No required raw-input gaps found in this extraction.
