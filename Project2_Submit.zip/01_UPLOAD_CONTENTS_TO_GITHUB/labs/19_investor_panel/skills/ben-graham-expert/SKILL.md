---
name: ben-graham-expert
description: Apply the Lab 19 Graham liquidity and earnings screens with an editable current-ratio rule and explicit threshold sensitivity.
---

Use the shared engine in `../../panel.py` and read [rules.json](rules.json). Baseline current-ratio minimum is 2.0. Change `current_ratio_min` here in the skill's rules file to 1.0 for the requested probe, rerun, then restore the retained policy. The engine also offers `--graham-current-ratio 1.0` for an isolated override. Record the retained threshold and why directly beneath Graham's memo.

Check the latest current ratio; positive net income every year; final net income above the first year. Use five annual periods and unrounded values. These are the assignment's simplified rules, not all of Graham's historical criteria. Do not claim a margin of safety without verified price and valuation inputs.

Use only numbers printed for that company's run. Missing current assets or liabilities remain `not found`; the ratio and dependent check remain `not known`. Never substitute a bank liquidity measure for the current ratio. Run `python panel.py --audit-memos` after writing memos. The persona is an AI-assisted simulation, not Graham speaking.
