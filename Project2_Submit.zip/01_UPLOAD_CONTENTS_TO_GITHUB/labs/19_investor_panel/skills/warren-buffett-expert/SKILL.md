---
name: warren-buffett-expert
description: Apply the Lab 19 Buffett profitability and owner-earnings screens to a shared SEC annual fact table, preserving missing inputs.
---

Use the shared engine in `../../panel.py`. Read the thresholds in [rules.json](rules.json); do not create a separate fact extraction for this persona.

Apply the lab's checks: ROE meets the configured minimum every year; owner earnings are positive every year; final owner earnings exceed the first year. Require five annual periods. ROE uses year-end equity to reproduce the assignment. Owner earnings is the disclosed OCF less all capex proxy, not a maintenance-capex estimate.

Use only numbers printed for that company's run. Missing facts stay `not found`; dependent checks stay `not known`. Explain cash generation, limitations of the proxy and valuation gaps. Do not turn a screen pass into a purchase recommendation or claim to represent the actual investor. Run `python panel.py --audit-memos` after writing memos.
