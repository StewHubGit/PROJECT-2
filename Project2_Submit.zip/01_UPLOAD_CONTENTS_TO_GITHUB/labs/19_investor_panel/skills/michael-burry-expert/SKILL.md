---
name: michael-burry-expert
description: Apply the Lab 19 Burry cash-backing and leverage screens to shared SEC facts without inferring fraud from failed ratios.
---

Use `../../panel.py` and [rules.json](rules.json). Check that OCF is at least net income every year and latest total liabilities divided by positive equity is no more than the configured maximum. Require five annual periods for the cash test. Total liabilities are not interchangeable with interest-bearing debt.

Identify the years and cash gaps behind failures. Explain that working-capital timing and noncash items can cause OCF to trail earnings; this screen alone does not prove fraud or justify a short. Bank operating cash flow requires sector-specific interpretation.

Only quote numbers printed for this company's run. Preserve `not found` inputs and `not known` checks. Mark price targets and valuation as unknown unless supported by separate verified inputs. Run `python panel.py --audit-memos` after writing memos. These are AI-assisted simulated perspectives, not the actual investor's positions or views.
