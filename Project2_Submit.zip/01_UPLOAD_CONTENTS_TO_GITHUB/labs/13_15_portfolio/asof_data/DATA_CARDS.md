# Point-in-time data cards

## AAA: supplied known-answer excerpt

| Field | Record |
| --- | --- |
| Source | Four AAA rows supplied by the user in this conversation on 27 October 2026. The complete course training table was not supplied. |
| Measure | Fictional monthly level used to teach publication timing; no financial instrument is asserted. |
| Units | Level/index units as supplied; signals are period percent changes. |
| Publication lag | January: 10 February, 10 calendar days after month-end. February: 10 March, 10 days; revision: 25 March, 25 days. March: 10 April, 10 days. |
| Revisions | February 104.0 becomes 103.0 on 25 March; never substitute it before that date. |
| Download date | Not downloaded. Transcribed from the user-supplied excerpt on 2026-10-27. |
| Row numbers | Assigned 1–4 in the order of the supplied excerpt and preserved thereafter; these are not claimed to be row numbers from the unavailable full training table. |
| Coverage | January–March 2026. February 28, March 31 and April 30 are demonstration decision dates chosen here. |

## Own-series extension: U.S. current-dollar GDP

| Field | Record |
| --- | --- |
| Source | U.S. Bureau of Economic Analysis historical releases linked below, read on 2026-10-27. Manually transcribed release values; not an ALFRED CSV download. |
| Measure | U.S. nominal gross domestic product, seasonally adjusted annual-rate level. This is a separate macro demonstration, not an input to the portfolio allocation. |
| Units | Billions of current U.S. dollars, SAAR. The script calculates a nonannualized quarter-to-quarter ratio of those levels; it does not report real GDP growth or BEA's annualized growth figure. |
| Publication lag | Q1 2011 advance: April 28 (28 days after March 31); second: May 26 (56 days); third: June 24 (85 days). The Q4 2010 row is its March 25 third estimate, 84 days after December 31; this sample does not contain its earlier estimates. |
| Revisions | Q1: 15006.4 → 15010.3 → 15018.1 on the three actual release dates. Q4 14871.4 is the preceding-quarter denominator at these vintages. Later annual revisions are excluded from this bounded sample. |
| Download date | No raw source file downloaded. Web pages accessed and values transcribed on 2026-10-27. |
| Coverage | Quarterly decisions 2011-03-25 through 2011-07-28 only; the CLI rejects dates outside this interval for the built-in own-series example. |
| Decision dates | April 29, May 31, June 30, 2011, all after the corresponding release. |
| Lag needed in a backtest | Use actual publication dates. Q1 is unavailable until April 28; a period-end label of January 1 or March 31 cannot establish availability. A fixed 28-day rule cannot reproduce the later revisions. |

Row-level source map:

| Original row | Period / value | Publication and verification source |
| --- | --- | --- |
| 1 | Q4 2010 / 14871.4 | [BEA, 25 March 2011, current-dollar GDP paragraph](https://www.bea.gov/news/2011/gross-domestic-product-4th-quarter-and-annual-2010-third-estimate-corporate-profits-4th) |
| 2 | Q1 2011 / 15006.4 | [BEA, 28 April 2011, current-dollar GDP paragraph](https://www.bea.gov/news/2011/gross-domestic-product-1st-quarter-2011-advance-estimate) |
| 3 | Q1 2011 / 15010.3 | [BEA, 26 May 2011, current-dollar GDP paragraph](https://www.bea.gov/news/2011/gross-domestic-product-1st-quarter-2011-second-estimate-corporate-profits-1st-quarter) |
| 4 | Q1 2011 / 15018.1 | [BEA, 24 June 2011, current-dollar GDP paragraph](https://www.bea.gov/index.php/news/2011/gross-domestic-product-1st-quarter-2011-third-estimate) |

## Using ALFRED for a larger series

[ALFRED](https://alfred.stlouisfed.org/help) archives historical vintages. An observation date describes the measured period; it is not a publication date. Use [observations by real-time period](https://alfred.stlouisfed.org/help/downloaddata), retaining the vintage start for each version and its source provenance. Normalize the observation period into `month_measured` and the real-time start into `published_on` only after verifying that the metadata supports that interpretation. ALFRED's date boundaries are [inclusive](https://fred.stlouisfed.org/docs/api/fred/realtime_period.html).

The script's input is a history of publications, not an arbitrary collection of snapshots labeled with their download dates. A single current-vintage FRED file does not supply that history. ALFRED real-time starts describe vintage validity; source release dates, ALFRED ingestion, and the time a particular investor received data can differ. The [API release-date documentation](https://fred.stlouisfed.org/docs/api/fred/releases_dates.html) explicitly distinguishes release dates from website availability. Record the availability basis in the data card. Date-only inputs support end-of-day decisions; an intraday decision needs release timestamps and time zones. If publication dates are missing or invalid, this filter quarantines the entire affected series rather than guessing its lag.
