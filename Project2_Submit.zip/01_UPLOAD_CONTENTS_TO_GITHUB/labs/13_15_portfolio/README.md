# Portfolio app and Meridian coursework

- [Lab 16: point-in-time filter and full training-table proof](../Lab16_Point_In_Time/README.md): from the main folder, run `.\.venv\Scripts\python.exe .\Lab16_Point_In_Time\asof.py`.
- [Lab 14: fund universe and Streamlit](Lab_14_Fund_Universe_Streamlit.md)
- [Lab 13: Meridian mandate](Lab_13_Meridian_Mandate.md) and [mandate review](Meridian_Portfolio_Mandate_Review.md)
- [Four-fund prices](prices.csv), [SPY prices](spy_prices.csv), and [SPY notes](SPY_prices_notes.md)
- App: `app.py`; calculation engine: `portfolio.py`; mandate checker: `mandate.py`.
- Data helpers: `download_fund_prices.py` and `fund_estimates.py`.
- Saved estimates and raw sources remain in [../outputs](../outputs).

From the main AIFinance2026 folder, run:

```powershell
.\.venv\Scripts\python.exe -m streamlit run .\Project2_Portfolio\app.py
.\.venv\Scripts\python.exe .\Project2_Portfolio\fund_estimates.py
```

Upload CSVs from this folder. Older commands in the lab notes predate the organization; use the paths above. [Main index](../README.md).
