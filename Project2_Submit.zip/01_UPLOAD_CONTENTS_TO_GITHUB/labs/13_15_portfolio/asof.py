"""Date-level point-in-time filter with a disposition for every original row.

No dependencies or network requests. The default AAA excerpt is supplied by the
user; it is not a reconstruction of the missing full course training table.
"""

import argparse
from calendar import monthrange
import csv
from datetime import date, datetime, timezone
from decimal import Decimal, InvalidOperation
import hashlib
import json
from pathlib import Path
import re


DATA = Path(__file__).resolve().parent / "asof_data"
REQUIRED = {"series", "month_measured", "value", "published_on"}
ORDER = ("quarantine", "duplicate", "late_publication", "superseded_revision", "retained")


def iso_date(value):
    if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", value):
        raise ValueError("expected YYYY-MM-DD")
    return date.fromisoformat(value)


def load_rows(path):
    """Assign a row number once if absent; preserve explicit row numbers."""
    with Path(path).open(newline="", encoding="utf-8-sig") as handle:
        reader = csv.DictReader(handle)
        headers = reader.fieldnames or []
        if len(headers) != len(set(headers)) or not REQUIRED.issubset(headers):
            raise ValueError(f"CSV needs unique columns including {sorted(REQUIRED)}")
        rows = []
        ids = set()
        for position, cells in enumerate(reader, 1):
            if None in cells or any(v is None for v in cells.values()):
                raise ValueError(f"CSV record {position}: wrong number of cells")
            row_id = cells.get("row_number", str(position)).strip()
            if not row_id or row_id in ids:
                raise ValueError(f"CSV record {position}: missing or repeated row_number")
            ids.add(row_id)
            rows.append({"row_number": row_id, "source_record": position, "raw": dict(cells)})
        if not rows:
            raise ValueError("CSV has no data rows")
        return rows


def prepare(rows, frequency="monthly"):
    """Quarantine before deduplication. Unknown publication quarantines a series."""
    step = {"monthly": 1, "quarterly": 3}[frequency]
    prepared = []
    unknown_publication = set()
    for source in rows:
        row = {**source, "status": None, "reason": "", "replaced_by": None}
        cells = row["raw"]
        row["series"] = cells["series"].strip()
        issues = []
        if not row["series"]:
            issues.append("missing series")
        try:
            row["published"] = iso_date(cells["published_on"].strip())
        except ValueError:
            issues.append("publication date missing or invalid")
            unknown_publication.add(row["series"])
        try:
            measured = cells["month_measured"].strip()
            if not re.fullmatch(r"\d{4}-\d{2}", measured):
                raise ValueError()
            row["period"] = iso_date(measured + "-01")
            if step == 3 and row["period"].month not in (1, 4, 7, 10):
                raise ValueError()
            last_month = row["period"].month + step - 1
            period_end = date(row["period"].year, last_month,
                              monthrange(row["period"].year, last_month)[1])
            if "published" in row and row["published"] < period_end:
                issues.append("publication precedes end of measured period")
        except ValueError:
            issues.append("invalid month_measured (quarterly uses quarter-start month)")
        try:
            row["number"] = Decimal(cells["value"].strip())
            if not row["number"].is_finite() or row["number"] <= 0:
                raise InvalidOperation()
        except InvalidOperation:
            issues.append("value must be a finite positive level")
        if issues:
            row["status"], row["reason"] = "quarantine", "; ".join(issues)
        prepared.append(row)

    for row in prepared:
        if row["series"] in unknown_publication:
            row["status"] = "quarantine"
            row["reason"] = "series quarantined: at least one publication date is unknown or invalid"

    # Dates alone cannot order conflicting publications on the same day.
    same_day = {}
    for row in prepared:
        if row["status"] is None:
            key = (row["series"], row["period"], row["published"])
            same_day.setdefault(key, []).append(row)
    for group in same_day.values():
        if len({r["number"] for r in group}) > 1:
            for row in group:
                row["status"] = "quarantine"
                row["reason"] = "conflicting values for the same series, period and publication day"

    seen = {}
    for row in prepared:
        if row["status"] is None:
            key = (row["series"], row["period"], row["published"], row["number"])
            if key in seen:
                row["status"] = "duplicate"
                row["replaced_by"] = seen[key]
                row["reason"] = f"exact data duplicate of original row {seen[key]}"
            else:
                seen[key] = row["row_number"]
    return prepared


def select(rows, decision_date, frequency="monthly", naive=False):
    """Select latest publication per period AFTER removing late publications.

    naive=True deliberately ignores the publication cutoff and uses the last
    vintage in the input file; measured periods still cannot end after decision.
    """
    cutoff = iso_date(decision_date) if isinstance(decision_date, str) else decision_date
    audit = [dict(row) for row in prepare(rows, frequency)]
    groups = {}
    for row in audit:
        if row["status"] is not None:
            continue
        if not naive and row["published"] > cutoff:
            row["status"], row["reason"] = "late_publication", "published after decision date"
            continue
        # Valid actuals publish after period end. This guard matters for naive.
        step = {"monthly": 1, "quarterly": 3}[frequency]
        last_month = row["period"].month + step - 1
        period_end = date(row["period"].year, last_month,
                          monthrange(row["period"].year, last_month)[1])
        if naive and period_end > cutoff:
            row["status"], row["reason"] = "future_period", "measured period ends after decision date"
            continue
        groups.setdefault((row["series"], row["period"]), []).append(row)
    for group in groups.values():
        winner = max(group, key=lambda r: r["published"])
        for row in group:
            if row is winner:
                row["status"], row["reason"] = "retained", "latest eligible publication for measured period"
            else:
                row["status"] = "superseded_revision"
                row["replaced_by"] = winner["row_number"]
                row["reason"] = f"replaced by original row {winner['row_number']}"
    panel = sorted((r for r in audit if r["status"] == "retained"),
                   key=lambda r: (r["series"], r["period"]))
    assert len(audit) == len(rows) and all(r["status"] for r in audit)
    return panel, audit


def signals(panel, series_names, frequency="monthly"):
    """Latest level / immediately preceding period's level - 1, in percent."""
    result = {}
    step = {"monthly": 1, "quarterly": 3}[frequency]
    for name in sorted(series_names):
        observations = sorted((r for r in panel if r["series"] == name), key=lambda r: r["period"])
        record = {"signal_percent": None, "row_numbers": [], "reason": "fewer than two eligible periods"}
        if len(observations) >= 2:
            previous, latest = observations[-2:]
            gap = ((latest["period"].year - previous["period"].year) * 12
                   + latest["period"].month - previous["period"].month)
            record["row_numbers"] = [previous["row_number"], latest["row_number"]]
            if gap == step:
                record["signal_percent"] = (latest["number"] / previous["number"] - 1) * 100
                record["reason"] = "latest period / preceding period - 1"
            else:
                record["reason"] = "gap between latest two periods; no backfill"
        result[name] = record
    return result


def analyze(rows, decision_date, frequency="monthly"):
    panel, audit = select(rows, decision_date, frequency)
    naive_panel, naive_audit = select(rows, decision_date, frequency, naive=True)
    names = {r["raw"]["series"].strip() for r in rows}
    actual = signals(panel, names, frequency)
    naive = signals(naive_panel, names, frequency)
    comparison = {}
    for name in sorted(names):
        a, n = actual[name]["signal_percent"], naive[name]["signal_percent"]
        comparison[name] = {"asof": actual[name], "naive": naive[name],
                            "leak_percentage_points": None if a is None or n is None else n - a}
    return {"decision_date": decision_date, "frequency": frequency,
            "funnel": {status: sum(r["status"] == status for r in audit) for status in ORDER},
            "panel": panel, "audit": audit, "naive_panel": naive_panel,
            "naive_audit": naive_audit, "signals": comparison}


def display(result):
    print(f"\nDECISION DATE {result['decision_date']} (end of day)")
    remaining = len(result["audit"])
    print(f"ROW FUNNEL: input {remaining}")
    for status, count in result["funnel"].items():
        if status != "retained":
            remaining -= count
            print(f"  {status:23} remove {count:3} -> {remaining:3}")
    print(f"  retained                  {remaining:3}")
    print("AS-OF PANEL: original row | series | month measured | value | published on")
    for row in result["panel"]:
        print(f"  {row['row_number']} | {row['series']} | {row['period']:%Y-%m} | "
              f"{row['number']} | {row['published']}")
    if not result["panel"]:
        print("  (empty)")
    print("SIGNALS (%): series | as-of | naive | leak (percentage points)")
    for name, comp in result["signals"].items():
        values = (comp["asof"]["signal_percent"], comp["naive"]["signal_percent"],
                  comp["leak_percentage_points"])
        formatted = ["N/A" if v is None else f"{v:+.2f}" for v in values]
        print(f"  {name} | " + " | ".join(formatted))
        for label in ("asof", "naive"):
            if comp[label]["signal_percent"] is None:
                print(f"    {label}: {comp[label]['reason']}")
    print("ROW DISPOSITIONS:")
    for row in result["audit"]:
        print(f"  row {row['row_number']}: {row['status']} -- {row['reason']}")


def known_answer():
    """Check against the user's arithmetic, independently of displayed rounding."""
    result = analyze(load_rows(DATA / "training.csv"), "2026-03-31")
    aaa = result["signals"]["AAA"]
    expected_asof = (Decimal("103") / Decimal("101") - 1) * 100
    expected_naive = (Decimal("109") / Decimal("103") - 1) * 100
    checks = {
        "surviving_original_rows_1_and_3": [r["row_number"] for r in result["panel"]] == ["1", "3"],
        "row_2_superseded": result["audit"][1]["status"] == "superseded_revision",
        "row_4_not_yet_published": result["audit"][3]["status"] == "late_publication",
        "asof_exact": aaa["asof"]["signal_percent"] == expected_asof,
        "naive_exact": aaa["naive"]["signal_percent"] == expected_naive,
        "leak_exact": aaa["leak_percentage_points"] == expected_naive - expected_asof,
        "rounded_1_98_5_83_3_85": [f"{v:.2f}" for v in (
            aaa["asof"]["signal_percent"], aaa["naive"]["signal_percent"],
            aaa["leak_percentage_points"])] == ["1.98", "5.83", "3.85"],
    }
    if not all(checks.values()):
        raise ValueError(f"Known answer failed: {checks}")
    return checks


def json_value(value):
    if isinstance(value, (date, Decimal)):
        return str(value)
    raise TypeError(type(value).__name__)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, help="CSV with series, month_measured, value, published_on")
    parser.add_argument("--dates", nargs="+", help="decision dates in YYYY-MM-DD format")
    parser.add_argument("--frequency", choices=("monthly", "quarterly"))
    parser.add_argument("--own-series", action="store_true", help="run the documented BEA nominal-GDP example")
    parser.add_argument("--output", type=Path, help="optional full JSON receipt, including every row")
    args = parser.parse_args(argv)
    if args.csv and args.own_series:
        parser.error("choose --csv or --own-series")
    if args.csv and not args.dates:
        parser.error("--csv requires explicit --dates")
    try:
        checks = known_answer()
        path = args.csv or DATA / ("own_gdp.csv" if args.own_series else "training.csv")
        if args.output and args.output.resolve() == path.resolve():
            raise ValueError("output must not overwrite the input CSV")
        frequency = args.frequency or ("quarterly" if args.own_series else "monthly")
        dates = args.dates or (["2011-04-29", "2011-05-31", "2011-06-30"] if args.own_series
                               else ["2026-02-28", "2026-03-31", "2026-04-30"])
        for cutoff in dates:
            iso_date(cutoff)
        rows = load_rows(path)
        print("POINT-IN-TIME FILTER | known-answer proof: PASS (7 checks)")
        print(f"Input: {path}")
        if not args.csv:
            print("BEA release sample, valid March 25-July 28, 2011." if args.own_series else
                  "User-supplied AAA excerpt (4 rows); dates selected for this demonstration.")
        print("Order: quarantine -> duplicates -> late publications -> revisions.")
        print("Naive deliberately ignores publication dates; it uses latest vintages in this file.")
        print("Signals compare consecutive positive levels; no annualization or missing-period backfill.")
        if args.own_series and (frequency != "quarterly" or
                any(not "2011-03-25" <= cutoff <= "2011-07-28" for cutoff in dates)):
            raise ValueError("BEA excerpt supports quarterly decisions only within 2011-03-25..2011-07-28")
        results = [analyze(rows, cutoff, frequency) for cutoff in dates]
        for result in results:
            display(result)
        if args.output:
            receipt = {"generated_at_utc": datetime.now(timezone.utc).isoformat(),
                       "input": str(path.resolve()), "input_sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
                       "known_answer_checks": checks, "results": results}
            args.output.parent.mkdir(parents=True, exist_ok=True)
            args.output.write_text(json.dumps(receipt, indent=2, default=json_value) + "\n", encoding="utf-8")
            print(f"\nSaved full row audit: {args.output}")
        return 0
    except (OSError, ValueError) as exc:
        parser.error(str(exc))


if __name__ == "__main__":
    raise SystemExit(main())
