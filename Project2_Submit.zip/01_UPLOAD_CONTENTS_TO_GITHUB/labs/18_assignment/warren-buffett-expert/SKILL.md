---
name: warren-buffett-expert
description: "Run the SEC-only Buffett business-quality screen: code prints five annual 10-K periods and three checks, then the model writes a short numerically audited memo without price data."
---

# Buffett: code computes, model judges

Read the Buffett investor page only for its business-quality philosophy: [FAskills source](https://github.com/CinderZhang/FAskills/blob/8d5e14fc44df57cd37fdc5f041e43d773e37c196/financial-researcher/experts/warren_buffett.md). Never install FAskills or use its paid data sources. The user-specified rules below govern this skill, including its definition of owner earnings.

Run the bundled `scripts/buffett.py TICKER` with explicit `--cache` and `--output` folders. Use a real requester name and email in `SEC_USER_AGENT` or `--user-agent`; ask if unavailable. There is no API key. The script reads SEC `company_tickers.json`, pads the CIK to ten digits and downloads `companyfacts`. Use `--offline` only for a disclosed saved snapshot; use `--refresh` for a fresh download. A verified explicit `--cik` is supported when ticker lookup is blocked, and is recorded in the evidence.

The printed table contains the last five fiscal years, oldest first, labeled by fiscal-year-end date, in $ millions. Facts must be form 10-K. Flows require a calendar-year or 52/53-week period. For the same fiscal period the latest eligible filing wins; the filing cutoff is end-of-day. Revenue tags: `RevenueFromContractWithCustomerExcludingAssessedTax`, then `Revenues`. Net income: `NetIncomeLoss`. CFO: `NetCashProvidedByUsedInOperatingActivities`. Capital spending: `PaymentsToAcquirePropertyPlantAndEquipment`, then `PaymentsToAcquireProductiveAssets`. Equity: `StockholdersEquity`. No custom or estimated substitutes.

ROE is net income divided by year-end equity. Owner earnings is CFO minus capital spending. A missing raw value or owner earnings prints `not found`. With nonpositive or missing equity, ROE and liabilities/equity are `not known`. A check with a missing required input is `not known`. Python evaluates exactly these checks: ROE at least fifteen percent every year; owner earnings positive every year; owner earnings increased from the oldest year to the newest. All checks use unrounded amounts.

Read `printed.txt`, judge the business, and save a short model-written `memo.md` alongside it. Choose **own the business**, **watch it**, or **pass** and explain the evidence and uncertainty. Use only numbers printed by the script. Do not calculate additional amounts in prose. No prices, valuations, targets, market-timing claims or holdings claims this week. For JPM with absent capital spending, the memo must explicitly say **cannot judge owner earnings**. The arithmetic screen alone does not establish a moat or management integrity. Describe the voice as a simulated Buffett-style educational assessment, not actual Buffett or Berkshire views.

Run `audit_memo(memo, print_report(report))` from the script or use the app's memo box. Every unprinted numeric token must be flagged. If a flagged number is intended, rerun code to print the justified calculation; never whitelist an invented number. The audit proves token provenance only, not contextual correctness.

Save a separate one-line `decision.md` stating whether you trust the memo and why; label an AI-drafted decision as a draft for the user to review. Keep the user's full disclaimer with the app and evidence. The app must place this exact disclosure below its title: `data from SEC EDGAR; built with AI help, a learning demonstration, not investment advice.`

Validate with the provided COST known answer, the JPM missing-data probe, and an added `40.0%` in the COST memo. Read [acceptance.md](references/acceptance.md) for the exact expected data. Known answers belong only in validation fixtures, never the engine or app.
