"""Repeatable Buffett checks from keyless SEC 10-K companyfacts. No prices."""
from __future__ import annotations
import argparse
from datetime import date, datetime, timezone
from decimal import Decimal, ROUND_HALF_UP
import hashlib
import json
import math
import os
from pathlib import Path
import re
import time
import requests

NOT_FOUND = "not found"
NOT_KNOWN = "not known"
DISCLOSURE = "data from SEC EDGAR; built with AI help, a learning demonstration, not investment advice."
DISCLAIMER = "Disclaimer: This tool is for educational and informational purposes only. It does not constitute financial advice, investment recommendations, or professional guidance of any kind. The analyses generated are AI-simulated perspectives and should not be used as the basis for any investment decisions. Always consult a qualified financial advisor before making investment decisions. Use at your own risk."
TAGS = {
    "revenue": ("RevenueFromContractWithCustomerExcludingAssessedTax", "Revenues"),
    "net_income": ("NetIncomeLoss",),
    "operating_cash_flow": ("NetCashProvidedByUsedInOperatingActivities",),
    "capital_spending": ("PaymentsToAcquirePropertyPlantAndEquipment", "PaymentsToAcquireProductiveAssets"),
    "equity": ("StockholdersEquity",),
    "liabilities": ("Liabilities",),
}
FLOWS = {"revenue", "net_income", "operating_cash_flow", "capital_spending"}
NUMBER_PATTERN = re.compile(r"\d{4}-\d{2}-\d{2}|[-+−]?\$?\d+(?:,\d{3})*(?:\.\d+)?%?")


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, allow_nan=False), encoding="utf-8")


def numeric(value):
    return type(value) in (int, float) and math.isfinite(value)


class DataError(ValueError):
    pass


class SEC:
    def __init__(self, cache, identity="", offline=False, refresh=False):
        self.cache, self.identity = Path(cache), identity.strip()
        self.offline, self.refresh = offline, refresh
        self.receipts = []
        self.last_request = 0.0
        if offline and refresh:
            raise DataError("Choose offline or refresh, not both.")

    def get(self, url):
        if not re.match(r"https://(?:www|data)\.sec\.gov/", url):
            raise DataError("Only SEC HTTPS sources are permitted.")
        key = sha(url.encode())
        target, receipt = self.cache / (key + ".json"), self.cache / (key + ".receipt.json")
        cached = target.exists() and receipt.exists() and not self.refresh
        if cached:
            raw = target.read_bytes()
            meta = json.loads(receipt.read_text(encoding="utf-8"))
            if meta["sha256"] != sha(raw) or meta["url"] != url:
                raise DataError("SEC snapshot checksum or URL mismatch.")
        else:
            if self.offline:
                raise DataError(f"Saved SEC snapshot not found: {url}")
            if not re.search(r"\S+@\S+\.\S+", self.identity) or len(self.identity.split()) < 2:
                raise DataError("Set SEC_USER_AGENT to your real name and email. No API key is required.")
            for attempt in range(3):
                time.sleep(max(0, 0.25 - (time.monotonic() - self.last_request)))
                self.last_request = time.monotonic()
                try:
                    response = requests.get(url, headers={"User-Agent": self.identity, "Accept-Encoding": "gzip, deflate"}, timeout=45)
                except requests.RequestException as exc:
                    raise DataError(f"SEC network error: {exc}") from exc
                if response.status_code in {429, 500, 502, 503, 504} and attempt < 2:
                    time.sleep(2 ** attempt)
                    continue
                if response.status_code != 200:
                    raise DataError(f"SEC HTTP {response.status_code}: {url}. No data substituted.")
                break
            raw = response.content
            try:
                json.loads(raw)
            except (ValueError, UnicodeDecodeError) as exc:
                raise DataError("SEC returned invalid JSON; snapshot was not saved.") from exc
            self.cache.mkdir(parents=True, exist_ok=True)
            meta = {"url": url, "retrieved_at_utc": datetime.now(timezone.utc).isoformat(), "sha256": sha(raw), "bytes": len(raw)}
            target.write_bytes(raw)
            write_json(receipt, meta)
        self.receipts.append({**meta, "cached": cached})
        return json.loads(raw)


def cik_for(sec, ticker, explicit_cik=None):
    ticker = ticker.strip().upper()
    if not re.fullmatch(r"[A-Z][A-Z0-9.\-]{0,11}", ticker):
        raise DataError("Enter a valid US ticker.")
    if explicit_cik:
        if not re.fullmatch(r"\d{1,10}", explicit_cik):
            raise DataError("An explicit CIK must have up to ten digits.")
        return explicit_cik.zfill(10)
    directory = sec.get("https://www.sec.gov/files/company_tickers.json")
    found = [str(v["cik_str"]).zfill(10) for v in directory.values() if v["ticker"] == ticker]
    if len(found) != 1:
        raise DataError(f"Ticker {ticker} not uniquely found in SEC directory.")
    return found[0]


def annual(item):
    if not item.get("start"):
        return False
    # Calendar years and 52/53-week fiscal years, with inclusive XBRL dates.
    days = (date.fromisoformat(item["end"]) - date.fromisoformat(item["start"])).days + 1
    return days in {364, 365, 366, 371}


def eligible(item, cutoff, flow):
    return item.get("form") == "10-K" and item.get("filed", "9999") <= cutoff and item.get("end", "9999") <= cutoff and numeric(item.get("val")) and (annual(item) if flow else not item.get("start"))


def select_fact(facts, metric, end, cutoff):
    gaap = facts.get("facts", {}).get("us-gaap", {})
    candidates = []
    for priority, tag in enumerate(TAGS[metric]):
        for item in gaap.get(tag, {}).get("units", {}).get("USD", []):
            if item.get("end") == end and eligible(item, cutoff, metric in FLOWS):
                candidates.append((item, priority, tag))
    if not candidates:
        return {"value": NOT_FOUND, "tag": NOT_FOUND, "reason": "No eligible USD fact using the required tags."}
    # Later 10-K comparisons replace older disclosures for the same fiscal period.
    newest = max((x[0]["filed"], x[0].get("accn", "")) for x in candidates)
    latest = [x for x in candidates if (x[0]["filed"], x[0].get("accn", "")) == newest]
    priority = min(x[1] for x in latest)
    chosen = [x for x in latest if x[1] == priority]
    contexts = {(x[0].get("start"), x[0]["end"], x[0]["val"]) for x in chosen}
    if len(contexts) != 1:
        return {"value": NOT_FOUND, "tag": chosen[0][2], "reason": "Conflicting annual/entity contexts in latest filing; no estimate made."}
    item, _, tag = chosen[0]
    return {"value": item["val"], "tag": tag, "unit": "USD", "start": item.get("start", NOT_FOUND), "end": item["end"], "filed": item["filed"], "accession": item.get("accn", NOT_FOUND)}


def three_checks(rows):
    def every(values, predicate):
        if len(rows) != 5 or any(not numeric(v) for v in values):
            return NOT_KNOWN
        return "pass" if all(predicate(v) for v in values) else "fail"
    roe = every([r["roe_percent"] for r in rows], lambda x: x >= 15)
    positive = every([r["owner_earnings"] for r in rows], lambda x: x > 0)
    first, last = rows[0]["owner_earnings"], rows[-1]["owner_earnings"]
    grew = NOT_KNOWN if len(rows) != 5 or not numeric(first) or not numeric(last) else "pass" if last > first else "fail"
    return {"ROE of 15% or more every year": roe, "Owner earnings positive every year": positive, "Owner earnings grew, first year to last": grew}


def compute(facts, ticker, cutoff):
    gaap = facts.get("facts", {}).get("us-gaap", {})
    ends = sorted({x["end"] for metric in FLOWS for tag in TAGS[metric] for x in gaap.get(tag, {}).get("units", {}).get("USD", []) if eligible(x, cutoff, True)})[-5:]
    if not ends:
        raise DataError("No eligible one-year USD 10-K facts found.")
    rows = []
    for end in ends:
        inputs = {key: select_fact(facts, key, end, cutoff) for key in TAGS}
        v = {k: x["value"] for k, x in inputs.items()}
        cfo, capex, equity, ni, liabilities = (v[k] for k in ("operating_cash_flow", "capital_spending", "equity", "net_income", "liabilities"))
        oe = cfo - capex if numeric(cfo) and numeric(capex) else NOT_FOUND
        roe = ni / equity * 100 if numeric(ni) and numeric(equity) and equity > 0 else NOT_KNOWN
        le = liabilities / equity if numeric(liabilities) and numeric(equity) and equity > 0 else NOT_KNOWN
        rows.append({"fiscal_year_end": end, **v, "roe_percent": roe, "owner_earnings": oe, "liabilities_to_equity": le, "inputs": inputs, "derived_tags": {"roe_percent": "NetIncomeLoss / StockholdersEquity × 100" if numeric(roe) else NOT_KNOWN, "owner_earnings": f"{inputs['operating_cash_flow']['tag']} - {inputs['capital_spending']['tag']}" if numeric(oe) else NOT_FOUND}})
    report = {"ticker": ticker.upper(), "company": facts.get("entityName", ticker.upper()), "cik": str(facts.get("cik", "")).zfill(10), "filing_cutoff": cutoff, "units": "USD amounts; printed table is $ millions", "selection": "10-K only; one-year flows; latest eligible filing wins for each fiscal period; exact required tags", "rows": rows, "checks": three_checks(rows), "disclosure": DISCLOSURE, "disclaimer": DISCLAIMER}
    report["evidence_fingerprint"] = sha(json.dumps({"rows": rows, "checks": report["checks"]}, sort_keys=True).encode())
    return report


def build(sec, ticker, cutoff, explicit_cik=None):
    date.fromisoformat(cutoff)
    if cutoff > date.today().isoformat():
        raise DataError("Filing cutoff cannot be in the future.")
    cik = cik_for(sec, ticker, explicit_cik)
    facts = sec.get(f"https://data.sec.gov/api/xbrl/companyfacts/CIK{cik}.json")
    if str(facts.get("cik", "")).zfill(10) != cik:
        raise DataError("SEC facts CIK does not match ticker lookup.")
    report = compute(facts, ticker, cutoff)
    report["receipts"] = sec.receipts
    report["cik_lookup"] = "Explicit user-supplied CIK" if explicit_cik else "SEC company_tickers.json"
    report["engine_sha256"] = sha(Path(__file__).read_bytes())
    return report


def formatted(value, kind="money"):
    if not numeric(value):
        return value
    if kind == "money":
        number = Decimal(str(value)) / Decimal(1_000_000)
        return f"{number:,.0f}" if number == number.to_integral() else f"{number:,.3f}"
    if kind == "roe":
        return str(Decimal(str(value)).quantize(Decimal("0.1"), rounding=ROUND_HALF_UP)) + "%"
    return f"{value:.3f}"


def print_report(report):
    lines = [f"{report['ticker']} — {report['company']}", "10-K only; last five fiscal years; latest eligible filing wins.", "All amounts below are $ millions; ROE is percent.", "FY end | Revenue | Net income | Operating cash flow | Capital spending | Equity | ROE | Owner earnings", "--- | ---: | ---: | ---: | ---: | ---: | ---: | ---:"]
    keys = ("revenue", "net_income", "operating_cash_flow", "capital_spending", "equity", "roe_percent", "owner_earnings")
    for row in report["rows"]:
        lines.append(row["fiscal_year_end"] + " | " + " | ".join(formatted(row[k], "roe" if k == "roe_percent" else "money") for k in keys))
    lines.append("\nXBRL provenance ($ values originate in USD facts):")
    for row in report["rows"]:
        lines.append(row["fiscal_year_end"])
        for metric in ("revenue", "net_income", "operating_cash_flow", "capital_spending", "equity"):
            fact = row["inputs"][metric]
            lines.append(f"  {metric}: {fact['tag']}; filed {fact.get('filed', NOT_FOUND)}; accession {fact.get('accession', NOT_FOUND)}")
        lines.append("  ROE: " + row["derived_tags"]["roe_percent"])
        lines.append("  owner_earnings: " + row["derived_tags"]["owner_earnings"])
        lines.append("  liabilities/equity: " + formatted(row["liabilities_to_equity"], "ratio"))
    lines.append("\nBuffett checks (unrounded inputs; ROE threshold 15%):")
    lines.extend(f"{name}: {result}" for name, result in report["checks"].items())
    lines.append("\n" + DISCLOSURE)
    return "\n".join(lines) + "\n"


def number_tokens(text):
    return [m.group() for m in NUMBER_PATTERN.finditer(text)]


def normalize_token(token):
    return token.replace(",", "").replace("$", "").replace("−", "-").lstrip("+")


def audit_memo(memo, printed):
    allowed = {normalize_token(t) for t in number_tokens(printed)}
    return sorted({t for t in number_tokens(memo) if normalize_token(t) not in allowed})


def export(report, output):
    output = Path(output)
    output.mkdir(parents=True, exist_ok=True)
    write_json(output / "evidence.json", report)
    printed = print_report(report)
    (output / "printed.txt").write_text(printed, encoding="utf-8")
    instructions = "Read the Buffett skill. Write a short educational Buffett-style memo: own the business, watch it, or pass. Judge the business, not the price. Use only numbers in the script printout below. Missing owner earnings must be explicitly unassessed. No prices, targets, valuations or holdings claims. Add a separate human-review decision under the memo.\n\n" + printed
    (output / "memo_prompt.md").write_text(instructions, encoding="utf-8")
    return printed


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("ticker")
    p.add_argument("--asof", default=date.today().isoformat())
    p.add_argument("--cache", type=Path, default=Path(__file__).resolve().parents[2] / "evidence/downloads")
    p.add_argument("--output", type=Path)
    p.add_argument("--user-agent", default=os.getenv("SEC_USER_AGENT", ""))
    p.add_argument("--cik", help="Explicit verified CIK if SEC ticker lookup is unavailable")
    p.add_argument("--offline", action="store_true")
    p.add_argument("--refresh", action="store_true")
    a = p.parse_args()
    try:
        report = build(SEC(a.cache, a.user_agent, a.offline, a.refresh), a.ticker, a.asof, a.cik)
        print(export(report, a.output or Path(__file__).resolve().parents[2] / "outputs" / a.ticker.upper()))
    except (DataError, ValueError, KeyError) as exc:
        p.exit(1, f"Cannot compute: {exc}\n")


if __name__ == "__main__":
    main()
