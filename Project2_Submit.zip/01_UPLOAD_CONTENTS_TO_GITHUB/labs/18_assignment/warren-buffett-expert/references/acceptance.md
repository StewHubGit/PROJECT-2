# Acceptance criteria supplied by the user

Costco, $ millions; ROE displayed to one decimal place:

| FY end | Revenue | Net income | Operating cash flow | Capital spending | Equity | ROE % | Owner earnings |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 2022-08-28 | 226954 | 5844 | 7392 | 3891 | 20642 | 28.3 | 3501 |
| 2023-09-03 | 242290 | 6292 | 11068 | 4323 | 25058 | 25.1 | 6745 |
| 2024-09-01 | 254453 | 7367 | 11339 | 4710 | 23622 | 31.2 | 6629 |
| 2025-08-31 | 275235 | 8099 | 13335 | 5498 | 29164 | 27.8 | 7837 |
| 2026-08-30 | 303154 | 9226 | 15817 | 6435 | 35803 | 25.8 | 9382 |

All three checks pass. Every cell must match, or investigate selection and units rather than pasting expected values into the engine.

JPMorgan: capital spending and owner earnings are `not found`; both owner-earnings checks are `not known`. Its model memo explicitly says it cannot judge owner earnings. Do not fill the gap with zero, a bank-specific proxy or an estimate.

COST memo probe: append `ROE was 40.0%.` The app must flag `40.0%`. Remove it for the final memo. Explain that the five displayed ROEs come from the script's SEC net-income and year-end-equity inputs, with source tags and filing accessions in the printout; they are not recalled or invented by the model.
