# Packaging verification

The packaged copy was tested on 2026-11-03 with the existing workspace Python environment:

```text
python -m unittest discover -s Lab18_Submission/tests -v
Ran 7 tests
OK
```

Covered: latest comparative filing selection, exact source-tag restrictions, productive-assets fallback, annual periods including a fiscal year with an extra week, year-end-equity ROE, nonpositive-equity handling, all three checks, missing-input labels, and the Streamlit memo-number flag.

The Streamlit test used an isolated temporary synthetic fixture. It did not populate submission outputs with the known answer or claim a live SEC match.

Pending: live COST cell-by-cell acceptance, live JPM missing-data probe, verified model-written memos and the final trust decision. No real requester email was supplied for the required SEC User-Agent.
