from datetime import date, timedelta
import json
from pathlib import Path
import shutil
import sys
import tempfile
import unittest
from streamlit.testing.v1 import AppTest

HERE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(HERE / "warren-buffett-expert/scripts"))
from buffett import TAGS, compute, export


class AppTests(unittest.TestCase):
    def test_memo_probe_on_isolated_synthetic_fixture(self):
        # Synthetic UI fixture only. This is never a substitute for SEC acceptance.
        known = json.loads((HERE / "tests/cost_known_answer.json").read_text(encoding="utf-8"))
        facts = {"entityName": "Synthetic Costco UI fixture", "cik": 909832, "facts": {"us-gaap": {}}}
        metrics = ["revenue", "net_income", "operating_cash_flow", "capital_spending", "equity"]
        for metric in metrics:
            records = []
            for index, row in enumerate(known):
                end = date.fromisoformat(row[0])
                start = (date.fromisoformat(known[index - 1][0]) + timedelta(days=1)) if index else (end - timedelta(days=363))
                item = {"end": row[0], "val": row[metrics.index(metric) + 1] * 1_000_000, "filed": "2026-10-01", "accn": "synthetic-ui-fixture", "form": "10-K"}
                if metric != "equity":
                    item["start"] = start.isoformat()
                records.append(item)
            facts["facts"]["us-gaap"][TAGS[metric][0]] = {"units": {"USD": records}}
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            shutil.copy(HERE / "app.py", root / "app.py")
            shutil.copytree(HERE / "warren-buffett-expert", root / "warren-buffett-expert")
            report = compute(facts, "COST", "2026-11-03")
            report["receipts"] = []
            export(report, root / "outputs/COST")
            (root / "outputs/COST/memo.md").write_text("Watch it. ROE was 25.8%.", encoding="utf-8")
            app = AppTest.from_file(str(root / "app.py")).run(timeout=30)
            self.assertFalse(app.exception)
            self.assertIn("data from SEC EDGAR", app.caption[0].value)
            self.assertTrue(app.success)
            app.text_area[0].set_value("Watch it. ROE was 40.0%.").run(timeout=30)
            self.assertFalse(app.exception)
            self.assertIn("40.0%", app.error[0].value)


if __name__ == "__main__":
    unittest.main()
