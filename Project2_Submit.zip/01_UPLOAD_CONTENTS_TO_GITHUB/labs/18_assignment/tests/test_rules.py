import copy
import json
from pathlib import Path
import sys
import unittest

HERE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(HERE / "warren-buffett-expert/scripts"))
from buffett import TAGS, audit_memo, compute, formatted, select_fact, three_checks


def entry(value, **changes):
    return {"start": "2025-01-01", "end": "2025-12-31", "val": value, "filed": "2026-02-01", "accn": "older", "form": "10-K", **changes}


def payload(metric, entries, tag=None):
    return {"cik": 1, "entityName": "Test company", "facts": {"us-gaap": {tag or TAGS[metric][0]: {"units": {"USD": entries}}}}}


class RuleTests(unittest.TestCase):
    def test_latest_comparative_10k_wins(self):
        facts = payload("revenue", [entry(100), entry(120, filed="2026-10-01", accn="newer"), entry(999, form="10-Q", filed="2026-10-02"), entry(999, start="2025-10-01", filed="2026-10-03")])
        self.assertEqual(select_fact(facts, "revenue", "2025-12-31", "2026-11-03")["value"], 120)
        self.assertEqual(select_fact(facts, "revenue", "2025-12-31", "2026-03-01")["value"], 100)

    def test_only_exact_revenue_and_net_income_tags(self):
        self.assertEqual(select_fact(payload("revenue", [entry(120)], "Revenues"), "revenue", "2025-12-31", "2026-11-03")["value"], 120)
        self.assertEqual(select_fact(payload("revenue", [entry(120)], "SalesRevenueNet"), "revenue", "2025-12-31", "2026-11-03")["value"], "not found")
        self.assertEqual(select_fact(payload("net_income", [entry(120)], "ProfitLoss"), "net_income", "2025-12-31", "2026-11-03")["value"], "not found")

    def test_productive_assets_fallback_and_53week_period(self):
        facts = payload("capital_spending", [entry(123, start="2022-08-29", end="2023-09-03")], "PaymentsToAcquireProductiveAssets")
        self.assertEqual(select_fact(facts, "capital_spending", "2023-09-03", "2026-11-03")["value"], 123)

    def test_year_end_equity_and_missing_input_rules(self):
        facts = payload("revenue", [entry(100)])
        for metric, value in (("net_income", 20), ("operating_cash_flow", 30), ("capital_spending", 10), ("equity", 100)):
            facts["facts"]["us-gaap"].update(payload(metric, [entry(value)] if metric != "equity" else [entry(value, start=None)])["facts"]["us-gaap"])
        r = compute(facts, "TEST", "2026-11-03")["rows"][0]
        self.assertEqual(r["roe_percent"], 20)
        self.assertEqual(r["owner_earnings"], 20)
        for eq in (0, -1):
            altered = copy.deepcopy(facts)
            altered["facts"]["us-gaap"]["StockholdersEquity"]["units"]["USD"][0]["val"] = eq
            row = compute(altered, "TEST", "2026-11-03")["rows"][0]
            self.assertEqual(row["roe_percent"], "not known")
            self.assertEqual(row["liabilities_to_equity"], "not known")
        del facts["facts"]["us-gaap"]["PaymentsToAcquirePropertyPlantAndEquipment"]
        self.assertEqual(compute(facts, "TEST", "2026-11-03")["rows"][0]["owner_earnings"], "not found")

    def test_three_checks_and_missing_data(self):
        rows = [{"roe_percent": 15.0, "owner_earnings": i + 1} for i in range(5)]
        self.assertEqual(list(three_checks(rows).values()), ["pass"] * 3)
        rows[0]["roe_percent"] = 14.999
        self.assertEqual(list(three_checks(rows).values())[0], "fail")
        for row in rows:
            row["owner_earnings"] = "not found"
        self.assertEqual(list(three_checks(rows).values())[1:], ["not known"] * 2)

    def test_number_audit_checks_percent_dates_sign_and_amounts(self):
        printed = "2026-08-30 9,382 25.8% 15% -100 10-K"
        self.assertEqual(audit_memo("Owner earnings 9,382; ROE 25.8%.", printed), [])
        self.assertEqual(audit_memo("ROE was 40.0%.", printed), ["40.0%"])
        self.assertEqual(audit_memo("40.0%and 100.", printed), ["100", "40.0%"])
        self.assertEqual(audit_memo("2026-08-30", printed), [])
        self.assertEqual(audit_memo("9.382 billion", printed), ["9.382"])


if __name__ == "__main__":
    unittest.main()
