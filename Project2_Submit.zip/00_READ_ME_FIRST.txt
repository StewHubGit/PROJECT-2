PROJECT 2 — SUBMISSION MATERIALS

01_UPLOAD_CONTENTS_TO_GITHUB
Upload the CONTENTS of this folder to your own repository root, preserving subfolders.
It includes the app, README, code, data, memo, validation report, evidence and video scripts.

YOUR VIDEO LINKS AND TRANSCRIPTS
1. Open videos/VIDEO_LINKS_AND_TRANSCRIPTS.md inside the GitHub folder.
2. Replace each PENDING YouTube URL with the actual link.
3. Paste matched transcripts into videos/transcripts/video-1.md, video-2.md and video-3.md.
4. Publish/review captions on YouTube; verify the instructor can open each video.
5. Fill the real repository/video/transcript locations in delivery.json and regenerate the manifest,
   or edit SUBMISSION_MANIFEST.md manually to use real GitHub locations except the YouTube links.
   The manifest currently marks unknown locations UNRESOLVED; it is not a finalized delivery manifest.

02_ATTACH_TO_BRIGHTSPACE
Attach decision-memo.md, validation-and-ai-use.md and SUBMISSION_MANIFEST.md.
They must exactly match the final GitHub versions. If you edit files on GitHub,
download those updated files for Brightspace so the versions match.
If you edit locally in this bundle, run python refresh_attachments.py afterward.

BRIGHTSPACE LINKS / TEXT
Paste your GitHub repository URL, the three real YouTube URLs, and the GitHub manifest URL.
Transcripts can be linked in the repo as prepared above. Do not submit video files.

LOCAL RECORDING APP
http://127.0.0.1:8512
This is a local recording address, not a public hosted-app submission link.
Other people start the app using the GitHub README; the supplied assignment does not require external hosting.

STATUS AND DISCLOSURES
Videos 1 and 2 were reported recorded; URLs/transcripts remain to be added.
The shown COST-01 changed-input example is explicitly AI-assisted and retrospective.
The separate required AI-off prediction committed before its run remains incomplete.
Personal ownership wording remains pending Sam's final confirmation in the source documents.
This folder assembles materials; no GitHub publishing or Brightspace submission has been performed.
