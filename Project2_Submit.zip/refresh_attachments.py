import runpy
from pathlib import Path

root = Path(__file__).resolve().parent
runpy.run_path(str(root / '01_UPLOAD_CONTENTS_TO_GITHUB/tools/prepare_delivery.py'), run_name='__main__')
for source in ['docs/decision-memo.md', 'docs/validation-and-ai-use.md', 'SUBMISSION_MANIFEST.md']:
    import shutil
    shutil.copyfile(root / '01_UPLOAD_CONTENTS_TO_GITHUB' / source,
                    root / '02_ATTACH_TO_BRIGHTSPACE' / Path(source).name)
print('Updated matching 02_ATTACH_TO_BRIGHTSPACE files.')
